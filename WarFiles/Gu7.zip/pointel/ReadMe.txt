Changes to be made in Guardian Client box : 

1.	"LoggerConfiguration.java" class should be changed under package com.pointel.ivr.util".

2.	NDM Property file name should be changed (Should be a common name), and also 

LoggerName = IvrAppLogger
LogFileSize = 25MB
LogDir = C:/logs
LogLevel = debug

3.	In initial page following code to be added for log purpose

	 String loggerName = proFlexxgate.getProperty("LoggerName"); 
		String logFileSize = proFlexxgate.getProperty("LogFileSize"); 
		String logDir = proFlexxgate.getProperty("LogDir");
		String logLevel = proFlexxgate.getProperty("LogLevel");
		
		
		String filepath="";
		Logger debugLogger = null;	
		//Get the Logger File Path
		if(logDir.endsWith("/")){
			filepath = logDir+loggerName+".log";
		}else{
			filepath = logDir+"/"+loggerName+".log";
		}
		
		//Configure the logger with the properties which are getting from Property files and System properties
		LoggerConfigure.loggerConfiguration(filepath, logFileSize.trim(),logLevel,loggerName);
		debugLogger = Logger.getLogger(loggerName);

	 <%@page import="com.pointel.ivr.util.*"%>
	 
4. 	Following code should be removed in all the pages

	Logger debugLogger = BackendLogManager.getLogger("debugLogger"); 
	Logger errorLogger = BackendLogManager.getLogger("errorLogger");	
	
5.	In Initial page and NDMProperties.jsp pages property file path should be changed.

