
The Vocabulary.master file you see here is used to generate grammars automatically with a tool called GramGen.  

The latest version of GramGen and it's associated documentation can be found under:

swi/coretech/OSRtools/GramGen

in the Product CVS repository.