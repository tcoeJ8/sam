package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import com.guardian.cct.reporting.*;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.Map;
import java.util.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class NDM_005fInit_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
    
    JSONObject result = new JSONObject();
    
    Logger logger = LogManager.getLogger("CUSTOM_LOGGER");
	String NDM_sessionID = state.getString("GVPSessionID").split(";")[0];
    String NDM_callID = state.getString("CallUUID").trim();	
    String NDM_logInfo = " {" + NDM_sessionID + "}, " + NDM_callID + ",";
	
	logger.debug(NDM_logInfo + "");
	logger.debug(NDM_logInfo + "******************************************");
	logger.debug(NDM_logInfo + "In NDM_Init");

	//Declare NDM Paramaters ..		
	String NDM_collectionInitialPrompt = "" ;
	String NDM_collectionNoInputPrompts1  = ""  , NDM_collectionNoInputPrompts2  = "" ;		
	String NDM_dmName = "" ;
	String NDM_failurePrompt = ""  ;
	String NDM_maxHelpCount = "" ;
	String NDM_maxNoInputs = "" ;
	String NDM_propertyBargeIn = "" ;
	String NDM_propertyFetchaudio = "" ;
	String NDM_successPrompts1 = "" , NDM_successPrompts2 = "" , NDM_successPrompts3 = "" ;
	String NDM_defaultConfirmation = "" ;
	String NDM_maxNoMatches = "" ;
	String NDM_maxTurns = "" ;
	String NDM_propertyInterDigitTimeout = "" ;
	String NDM_collectionCommandGrammar1 = "" ;
	String NDM_collectionDtmfCommandGrammar1 = "" ;
	String NDM_confirmationGrammar1 = "" ;
	String NDM_confirmationDtmfGrammar1 = "" ;
	String NDM_collectionNoMatchPrompt1 = "" ;
	String NDM_collectionNoMatchPrompt2 = "" ;
	String NDM_src = "" ;
	String NDM_minLength = "" ,  NDM_length = "" ;
	String NDM_collectionHelpPrompts1 = "" ;
	String NDM_collectionGrammar1 = "" , NDM_collectionDTMFGrammar1 = "" ;
	String NDM_confirmationInitialPrompt = "" ;
	String NDM_incompleteTimeout = "" , NDM_maxSpeechTimeout = "", NDM_disambigMode = "" ;
	String NDM_collectionHighConfidenceLevel = "" , NDM_propertyConfidenceLevel = "" , NDM_correctedCollectionConfidenceLevel = "" ;
	String NDM_minallowed = "" , NDM_maxallowed = "" ;
	String NDM_minexpected = "" , NDM_maxexpected = "" ;
	String NDM_granularityallowed = "" , NDM_granularityexpected = "" ;
	String NDM_maxinvalidanswers = "" , NDM_maxnotoconfirms = "" ;
	String NDM_property_sensitivity = "";
	String NDM_customdata = "", NDM_customSecondDate = "", NDM_customThirdDate = "";
	String NDM_propertyConfirmationConfidenceLevel = "" ;
	String NDM_confirmation_commandgrammar = "";
	String NDM_maxLength = "" ;
	String NDM_dmNumber = "" ;
	String NDM_customVar1 = "";

	
	
	try {			

		//Get values of NDM Parameter which are passed from Other Modules	
		PP_And_Dm_States dmReport=new PP_And_Dm_States();
		String StateName=state.getString("StateName");
		dmReport.createDMNodeConfig(NDM_callID,StateName);// Sarg Reporting
		NDM_collectionInitialPrompt = state.getString("NDM_collection_initialprompt");
		NDM_collectionNoInputPrompts1 = state.getString("NDM_collection_noinputprompts1");
		NDM_collectionNoInputPrompts2 = state.getString("NDM_collection_noinputprompts2");			
		NDM_dmName = state.getString("NDM_dmname");
		NDM_failurePrompt = state.getString("NDM_failureprompt");
		NDM_maxHelpCount = state.getString("NDM_maxhelpcount");
		NDM_maxNoInputs = state.getString("NDM_maxnoinputs");
		NDM_propertyBargeIn = state.getString("NDM_property_bargein");
		NDM_propertyFetchaudio =state.getString("NDM_property_fetchaudio");
		NDM_successPrompts1 = state.getString("NDM_successprompts1");
		NDM_successPrompts2 = state.getString("NDM_successprompts2");
		NDM_successPrompts3 = state.getString("NDM_successprompts3");
		NDM_defaultConfirmation = state.getString("NDM_defaultconfirmation");
		logger.debug("--NDM_defaultconfirmation-- " + NDM_defaultConfirmation);
		NDM_maxNoMatches = state.getString("NDM_maxnomatches");
		NDM_maxTurns = state.getString("NDM_maxturns");
		NDM_propertyInterDigitTimeout = state.getString("NDM_property_interdigittimeout");
		NDM_collectionCommandGrammar1 = state.getString("NDM_collection_commandgrammar1"); //collection_commandgrammar used for collection_parallelgrammar in ndm
		NDM_collectionDtmfCommandGrammar1 = state.getString("NDM_collection_dtmfcommandgrammar1"); //collection_dtmfcommandgrammar used for collection_dtmfparallelgrammar in ndm
		NDM_confirmationGrammar1 = state.getString("NDM_confirmation_grammar1");
		NDM_confirmationDtmfGrammar1 = state.getString("NDM_confirmation_dtmfgrammar1");
		NDM_collectionNoMatchPrompt1 = state.getString("NDM_collection_nomatchprompt1");
		NDM_collectionNoMatchPrompt2 = state.getString("NDM_collection_nomatchprompt2");
		NDM_src = state.getString("NDM_src");
		NDM_minLength = state.getString("NDM_minlength");
		NDM_maxLength = state.getString("NDM_maxlength");
		NDM_length = state.getString("NDM_length");
		NDM_collectionHelpPrompts1 = state.getString("NDM_collection_helpprompts1");
		NDM_collectionGrammar1 = state.getString("NDM_collection_grammar1");
		NDM_collectionDTMFGrammar1 = state.getString("NDM_collection_dtmfgrammar1");
		NDM_confirmationInitialPrompt =state.getString("NDM_confirmation_initialprompt");			
		NDM_customdata = state.getString("NDM_custom_data");
		NDM_customSecondDate = state.getString("NDM_custom_seconddate");
		NDM_customThirdDate = state.getString("NDM_custom_thirddate");			
		NDM_incompleteTimeout = state.getString("NDM_incompletetimeout");
		NDM_maxSpeechTimeout = state.getString("NDM_property_maxspeechtimeout");
		NDM_disambigMode = state.getString("NDM_disambiguationmode");
		NDM_customVar1 = state.getString("NDM_custom_customVar1");
		NDM_collectionHighConfidenceLevel = state.getString("NDM_collection_highconfidencelevel");
		NDM_propertyConfidenceLevel = state.getString("NDM_property_confidencelevel");
		NDM_correctedCollectionConfidenceLevel = state.getString("NDM_corrected_collection_confidencelevel"); //corrected_collection_confidencelevel used for property_collection_confidencelevel in ndm
		NDM_minallowed = state.getString("NDM_minallowed");
		NDM_maxallowed = state.getString("NDM_maxallowed");
		NDM_minexpected = state.getString("NDM_minexpected");
		NDM_maxexpected = state.getString("NDM_maxexpected");
		NDM_granularityallowed = state.getString("NDM_granularityallowed");
		NDM_granularityexpected = state.getString("NDM_granularityexpected");		
		NDM_property_sensitivity = state.getString("NDM_property_sensitivity");
		NDM_maxinvalidanswers = state.getString("NDM_maxinvalidanswers");
		NDM_maxnotoconfirms = state.getString("NDM_maxnotoconfirms");			
		NDM_propertyConfirmationConfidenceLevel = state.getString("NDM_property_confirmation_confidencelevel");
		NDM_confirmation_commandgrammar = state.getString("NDM_confirmation_commandgrammar");
		// Setting default values (later it can be overridden to user values, if provided)
		result.put("collection_highconfidencelevel","0.55");
		result.put("property_confidencelevel","0.55");
		result.put("corrected_collection_confidencelevel","0.55");
		result.put("incompletetimeout","1000ms");
		result.put("property_maxspeechtimeout", "12000ms");
		result.put("property_sensitivity", "0.5"); 
		result.put("confirmation_grammar1","boolean.grxml");
		// Setting DMType specific default values
		if (NDM_dmName.equalsIgnoreCase("date")){
			// Setting default values (later it can be overridden to user values, if provided)
			result.put("minallowed","20090101");
			result.put("maxallowed","20151231");				

		} else if (NDM_dmName.equalsIgnoreCase("currency")){
			// Setting default values (later it can be overridden to user values, if provided)
			result.put("minallowed","0.01");
			result.put("maxallowed","999999");
			result.put("minexpected","0.01");
			result.put("maxexpected","999999");
			result.put("granularityallowed","0.01");
			result.put("granularityexpected","1");				
		}		
		
		//Set collection_initialprompt			
		result.put("collection_initialprompt",NDM_collectionInitialPrompt);
		
		// Set the no input prompts
		if (NDM_collectionNoInputPrompts1.equalsIgnoreCase("none") || NDM_collectionNoInputPrompts1.equalsIgnoreCase("") ) {
			result.put("collection_noinputprompts1", "none");
		} else {
			result.put("collection_noinputprompts1", "" +  NDM_collectionNoInputPrompts1);
		}

		if (NDM_collectionNoInputPrompts2.equalsIgnoreCase("none") || NDM_collectionNoInputPrompts2.equalsIgnoreCase("") ) {
			result.put("collection_noinputprompts2", "none");
		} else {
			result.put("collection_noinputprompts2",  NDM_collectionNoInputPrompts2);
		}

		// Set Confirmation Grammar
		if (!NDM_confirmationGrammar1.equalsIgnoreCase("none")){
			result.put("confirmation_grammar1", NDM_confirmationGrammar1 );
		}
		

		// Set the no match prompts; Because, no answer apologies are deprecated and replaced by no match in NDM
		result.put("collection_nomatchprompt1",NDM_collectionNoMatchPrompt1);
		result.put("collection_nomatchprompt2",NDM_collectionNoMatchPrompt2);

		// Set the noto confirm prompts; Because, wrong answer apologies are deprecated and replaced by noto confirm in NDM
	
		result.put("collection_notoconfirmprompt1",NDM_collectionNoMatchPrompt1);
		result.put("collection_notoconfirmprompt2",NDM_collectionNoMatchPrompt2);			
		
		// Set incompletetimeout
		if (NDM_incompleteTimeout != null && !NDM_incompleteTimeout.equalsIgnoreCase("null")){
			if  (!NDM_incompleteTimeout.equalsIgnoreCase("none") && !NDM_incompleteTimeout.equalsIgnoreCase("")) {
				result.put("incompletetimeout",NDM_incompleteTimeout);
			}
		}
		
		// Set property_maxspeechtimeout
		if (NDM_maxSpeechTimeout != null && !NDM_maxSpeechTimeout.equalsIgnoreCase("null")){
			if  (!NDM_maxSpeechTimeout.equalsIgnoreCase("none") && !NDM_maxSpeechTimeout.equalsIgnoreCase("")) {
				result.put("property_maxspeechtimeout", NDM_maxSpeechTimeout );
			}
		}

		// Set disambiguationMode
		if (NDM_disambigMode != null && !NDM_disambigMode.equalsIgnoreCase("null")){
			if  (!NDM_disambigMode.equalsIgnoreCase("none") && !NDM_disambigMode.equalsIgnoreCase("")) {
				result.put("disambiguationmode",NDM_disambigMode);
			}
		} 

		// Set customVar1
		if (NDM_customVar1 != null && !NDM_customVar1.equalsIgnoreCase("null")){
			if  (!NDM_customVar1.equalsIgnoreCase("none") && !NDM_customVar1.equalsIgnoreCase("")) {
				result.put("custom_customVar1", NDM_customVar1);
			}
		}

		// Set collection_highconfidencelevel
		if (NDM_collectionHighConfidenceLevel != null && !NDM_collectionHighConfidenceLevel.equalsIgnoreCase("null")){
			if  (!NDM_collectionHighConfidenceLevel.equalsIgnoreCase("none") && !NDM_collectionHighConfidenceLevel.equalsIgnoreCase("")) {
				result.put("collection_highconfidencelevel",NDM_collectionHighConfidenceLevel);
			}
		}

		// Set property_confidencelevel
		if (NDM_propertyConfidenceLevel != null && !NDM_propertyConfidenceLevel.equalsIgnoreCase("null")){
			if  (!NDM_propertyConfidenceLevel.equalsIgnoreCase("none") && !NDM_propertyConfidenceLevel.equalsIgnoreCase("")) {
				result.put("property_confidencelevel",NDM_propertyConfidenceLevel);
			}
		}

		// Set corrected_collection_confidencelevel; But in NDM, property_collection_confidencelevel property renamed
		if (NDM_correctedCollectionConfidenceLevel != null && !NDM_correctedCollectionConfidenceLevel.equalsIgnoreCase("null")){
			if  (!NDM_correctedCollectionConfidenceLevel.equalsIgnoreCase("none") && !NDM_correctedCollectionConfidenceLevel.equalsIgnoreCase("")) {
				result.put("corrected_collection_confidencelevel",NDM_correctedCollectionConfidenceLevel);
			}
		} 

		// Set property_confirmation_confidencelevel property
		if (NDM_propertyConfirmationConfidenceLevel != null && !NDM_propertyConfirmationConfidenceLevel.equalsIgnoreCase("null")){
			if  (!NDM_propertyConfirmationConfidenceLevel.equalsIgnoreCase("none") && !NDM_propertyConfirmationConfidenceLevel.equalsIgnoreCase("")) {
				result.put("property_confirmation_confidencelevel",NDM_propertyConfirmationConfidenceLevel);
			}
		} 

		// Set minallowed
		if (NDM_minallowed != null && !NDM_minallowed.equalsIgnoreCase("null")){
			if  (!NDM_minallowed.equalsIgnoreCase("none") && !NDM_minallowed.equalsIgnoreCase("")) {
				result.put("minallowed",NDM_minallowed);
			}
		} 

		// Set maxallowed
		if (NDM_maxallowed != null && !NDM_maxallowed.equalsIgnoreCase("null")){
			if  (!NDM_maxallowed.equalsIgnoreCase("none") && !NDM_maxallowed.equalsIgnoreCase("")) {
				result.put("maxallowed","20151231");
			}
		} 

		// Set minexpected
		if (NDM_minexpected != null && !NDM_minexpected.equalsIgnoreCase("null")){
			if  (!NDM_minexpected.equalsIgnoreCase("none") && !NDM_minexpected.equalsIgnoreCase("")) {
				result.put("minexpected","0.01");
			}
		} 

		// Set maxexpected
		if (NDM_maxexpected != null && !NDM_maxexpected.equalsIgnoreCase("null")){
			if  (!NDM_maxexpected.equalsIgnoreCase("none") && !NDM_maxexpected.equalsIgnoreCase("")) {
				result.put("maxexpected",NDM_maxexpected);
			}
		} 

		// Set granularityallowed
		if (NDM_granularityallowed != null && !NDM_granularityallowed.equalsIgnoreCase("null")){
			if  (!NDM_granularityallowed.equalsIgnoreCase("none") && !NDM_granularityallowed.equalsIgnoreCase("")) {
				result.put("granularityallowed",NDM_granularityallowed);
			}
		} 

		// Set granularityexpected
		if (NDM_granularityexpected != null && !NDM_granularityexpected.equalsIgnoreCase("null")){
			if  (!NDM_granularityexpected.equalsIgnoreCase("none") && !NDM_granularityexpected.equalsIgnoreCase("")) {
				result.put("granularityexpected",NDM_granularityexpected);
			}
		} 

		// Set property_sensitivity
		if (NDM_property_sensitivity != null && !NDM_property_sensitivity.equalsIgnoreCase("null")){
			if  (!NDM_property_sensitivity.equalsIgnoreCase("none") && !NDM_property_sensitivity.equalsIgnoreCase("")) {
				result.put("property_sensitivity", NDM_property_sensitivity);
			}
		} 

		// Set maxinvalidanswers
		if (NDM_maxinvalidanswers != null && !NDM_maxinvalidanswers.equalsIgnoreCase("null")){
			if  (!NDM_maxinvalidanswers.equalsIgnoreCase("none") && !NDM_maxinvalidanswers.equalsIgnoreCase("")) {
				result.put("maxinvalidanswers",NDM_maxinvalidanswers);
			}
		} 

		// Set maxnotoconfirms
		if (NDM_maxnotoconfirms != null && !NDM_maxnotoconfirms.equalsIgnoreCase("null")){
			if  (!NDM_maxnotoconfirms.equalsIgnoreCase("none") && !NDM_maxnotoconfirms.equalsIgnoreCase("")) {
				result.put("maxnotoconfirms",NDM_maxnotoconfirms);
			}
		} 

		result.put("dmname",NDM_dmName);
		result.put("failureprompt",NDM_failurePrompt);
		result.put("maxnoinputs",NDM_maxNoInputs);
		result.put("maxhelpcount",NDM_maxHelpCount);
		result.put("property_bargein",NDM_propertyBargeIn);
		result.put("property_fetchaudio",NDM_propertyFetchaudio);
		result.put("successprompts1",NDM_successPrompts1);
		result.put("successprompts2",NDM_successPrompts2);
		result.put("successprompts3",NDM_successPrompts3);
		result.put("defaultconfirmation",NDM_defaultConfirmation);
		result.put("maxnomatches",NDM_maxNoMatches);
		result.put("maxturns",NDM_maxTurns);			
		result.put("collection_commandgrammar1",NDM_collectionCommandGrammar1);
		result.put("collection_dtmfcommandgrammar1",NDM_collectionDtmfCommandGrammar1);
		result.put("confirmation_dtmfgrammar1",NDM_confirmationDtmfGrammar1);
		result.put("src",NDM_src);
		result.put("minlength",NDM_minLength);
		result.put("maxlength",NDM_maxLength);
		result.put("length",NDM_length);
		result.put("collection_helpprompts1",NDM_collectionHelpPrompts1);
		result.put("collection_grammar1",NDM_collectionGrammar1);
		result.put("collection_dtmfgrammar1",NDM_collectionDTMFGrammar1);
		result.put("confirmation_initialprompt",NDM_confirmationInitialPrompt);
		result.put("custom_data", NDM_customdata);
		result.put("custom_seconddate", NDM_customSecondDate);
		result.put("custom_thirddate", NDM_customThirdDate);			
		result.put("confirmation_commandgrammar", NDM_confirmation_commandgrammar);

		

	} catch (Exception exc) {
		
		logger.error(NDM_logInfo +" Encountered exception NDM_Init: "+ exc.toString());
	}
	
	logger.info("--NDM parameters-- " + result.toString());
      
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
