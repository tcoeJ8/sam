package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import com.scansoft.guardian.fsa.service.ServiceManager;
import com.scansoft.guardian.fsa.bean.*;
import com.guardian.cct.reporting.*;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class GP3000_005fBroker_005fMenu_005fDM_005fCheck_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception 
{
        JSONObject result = new JSONObject();
      //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
        Logger debugLogger = Logger.getLogger("IvrAppLogger"); 
        
        String sessionID = state.getString("GVPSessionID").split(";")[0];
        String callID = state.getString("CallUUID").trim();
        Date timeStamp = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");    				
    	Calendar now = Calendar.getInstance();
    	String entryTime = dateFormat.format(now.getTime());
        String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
        boolean isDebugEnabled = false ;
        boolean pbdao;

        try{
        	 pbdao = false;
             ReportCall reportCall = null;
             String CXIhook = "";

             String retCode    =  state.getString("NDM_ReturnCode"); // response.getProperty("osdm.returncode", "missing");
             String retValue   =  state.getString("NDM_ReturnValue"); // response.getProperty("osdm.returnvalue", "missing");
             String dm_root_status = state.getString("NDM_dm_root_status");
             SessionObject.INSTANCE.getSession(callID).put("dm_root_status",dm_root_status);
            
         if( SessionObject.INSTANCE.getSession(callID)  !=  null )
           {

             isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
             reportCall =(ReportCall)SessionObject.INSTANCE.getSession(callID).get("ReportCallObj");
           	 CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
           }

         if (isDebugEnabled)
          {
            debugLogger.debug(loggingCommonFormat + " ");
            debugLogger.debug(loggingCommonFormat + "******************************************");
            debugLogger.debug(loggingCommonFormat + "GP3000_Broker_Menu_DM_Check");
            debugLogger.debug(loggingCommonFormat + "ReturnCode: " + retCode);
            debugLogger.debug(loggingCommonFormat + "ReturnValue: " + retValue);
          }


         if (retCode != null && retCode.equals("COMMAND"))
          { 
            result.put("NextCallFlow","transfer");
            result.put("event_msg","COMMAND ReturnCode");
          }
         if (retCode != null && retCode.equals("SUCCESS"))
          {       	        	 
                 // Database Integration start
                 SessionObject.INSTANCE.getSession(callID).put("adminGroupId",retValue);
                 JSONObject request = new JSONObject();
	                request.put("methodName", "checkBrokerPin");
	                request.put("daoClass","PBDAO");
	                request.put("pin", retValue);              
	                if (isDebugEnabled)
	                {
	        			debugLogger.debug(loggingCommonFormat +"Send Request as Input: " +request.toString());
	                }
	                ServiceManager sm = new ServiceManager();
	                JSONObject jsonResponse = new JSONObject();
	                jsonResponse = sm.execute(request);
	                if (isDebugEnabled){
	        			debugLogger.debug(loggingCommonFormat +"Get Response from Service:" + jsonResponse.toString());
	                }
					if(jsonResponse.has("response")){
						JSONObject jsonObj = jsonResponse.getJSONObject("response");
						pbdao = jsonObj.getBoolean("isBrokerPin");
						
						
	                }else{
	                	debugLogger.debug(loggingCommonFormat +"Json Response is wrong");
	                	 if(CXIhook.equals("Y"))
	                      {
	         			    	GenerateReport CXIreport  = new GenerateReport();
	           					JSONObject ivrTransacation = new JSONObject();
	           					ivrTransacation.put("ENTRY_TIME",entryTime);           
	           					ivrTransacation.put("DB_LOOKUP","Failure");
	    						ivrTransacation.put("FAILURE_REASON","dbGet");	 
	           					CXIreport.addFlow(callID,"GP3000_Broker_Menu", ivrTransacation);
	         			  }
	                	   result.put("NextCallFlow","transfer");
					} // Database Integration end             

                 if(pbdao)
            	  {
        	    	 reportCall.setCallReason("PREMIER BROKER");
                	 SessionObject.INSTANCE.getSession(callID).put("callerType","Premier_Broker");
                	 SessionObject.INSTANCE.getSession(callID).put("pinNumber",retValue);
                	 SessionObject.INSTANCE.getSession(callID).put("policyNumber","Unknown");
                	 debugLogger.debug(loggingCommonFormat + "Pin is found");
                	 reportCall.getReportCallData().put("CallReason", "PREMIER BROKER");	
                	 if(CXIhook.equals("Y"))
                      {
         			    	GenerateReport CXIreport  = new GenerateReport();
           					JSONObject ivrTransacation = new JSONObject();
           					ivrTransacation.put("ENTRY_TIME",entryTime);           
           					ivrTransacation.put("DB_LOOKUP","Success");
           				    ivrTransacation.put("CallReason","PREMIER BROKER");			 
           					CXIreport.addFlow(callID,"GP3000_Broker_Menu", ivrTransacation);
         			  }
                 }	
        	    	 
                else
        	     { 	  
                	 reportCall.setCallReason("PRODUCER");
                	 SessionObject.INSTANCE.getSession(callID).put("callerType","Producer");
                	 SessionObject.INSTANCE.getSession(callID).put("pinNumber","Unknown");
                	 SessionObject.INSTANCE.getSession(callID).put("policyNumber","Unknown");
                	 debugLogger.debug(loggingCommonFormat + "Pin is found");
                	 reportCall.getReportCallData().put("CallReason", "PRODUCER");
                	 if(CXIhook.equals("Y"))
                      {
         			    	GenerateReport CXIreport  = new GenerateReport();
           					JSONObject ivrTransacation = new JSONObject();
           					ivrTransacation.put("ENTRY_TIME",entryTime);    
           					ivrTransacation.put("DB_LOOKUP","Success");
           				    ivrTransacation.put("CallReason","PRODUCER");			 
           					CXIreport.addFlow(callID,"GP3000_Broker_Menu", ivrTransacation);
         			  }
        	     }
                result.put("NextCallFlow","transfer"); 
                result.put("event_msg","SUCCESS ReturnCode");
	     } 
        else 
         {        	
        	debugLogger.error(loggingCommonFormat + "Unhandled NDM response >"+" ReturnValue "+retValue+" ReturnCode "+retCode+" ReturnInputmode "+state.getString("NDM_ReturnInputmode")+" ReturnKey "+state.getString("NDM_ReturnKey")+" Failurereason "+state.getString("NDM_failurereason")+" ReturnResult "+state.getString("NDM_ReturnResult")+"<");        
            result.put("NextCallFlow","transfer");
            result.put("event_msg","Unhandled NDM response");
         }

      }catch(Exception exc) // Log Error Info 
      {
    	  debugLogger.error(loggingCommonFormat + "Encountered exception GP3000_Broker_Menu: " + exc.toString() );
      }
    return result;
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
