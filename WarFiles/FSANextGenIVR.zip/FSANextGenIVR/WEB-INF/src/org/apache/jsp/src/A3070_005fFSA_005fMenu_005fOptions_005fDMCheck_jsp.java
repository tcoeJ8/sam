package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import org.apache.log4j.Logger;
import java.util.Date;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class A3070_005fFSA_005fMenu_005fOptions_005fDMCheck_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
        JSONObject result = new JSONObject();
        
      //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
        Logger debugLogger = Logger.getLogger("IvrAppLogger"); 
        
        String sessionID = state.getString("GVPSessionID").split(";")[0];
        String callID = state.getString("CallUUID").trim();
        Date timeStamp = new Date();
        String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
        boolean isDebugEnabled = false ;

        try{
        	String callReason = null;
        	String appType = "";
            String retCode = state.getString("NDM_ReturnCode"); 
            String retValue = state.getString("NDM_ReturnValue"); 
            if( SessionObject.INSTANCE.getSession(callID)  !=  null )
             {
               isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
               callReason = (String) SessionObject.INSTANCE.getSession(callID).get("callReason");
               appType = (String) SessionObject.INSTANCE.getSession(callID).get("appType");
             }

            if (isDebugEnabled)
             {
               debugLogger.debug(loggingCommonFormat + " ");
               debugLogger.debug(loggingCommonFormat + "******************************************");
               debugLogger.debug(loggingCommonFormat + "A3070_FSA_Menu_Options_DMCheck");
               debugLogger.debug(loggingCommonFormat + "ReturnCode: " + retCode);
               debugLogger.debug(loggingCommonFormat + "ReturnValue: " + retValue);
             } 
            
            if (retCode != null && retCode.equals("COMMAND"))
            {
            	 if (isDebugEnabled)
              debugLogger.debug(loggingCommonFormat + "returnvalue:" + retValue);
      		  result.put("NextCallFlow","transfer");
      		  result.put("event_msg","COMMAND ReturnCode"); 
            }
            if (retCode != null && retCode.equals("SUCCESS"))
            {
            	 if (isDebugEnabled)
                debugLogger.debug(loggingCommonFormat + "returnvalue:" + retValue);
                     if(retValue != null && retValue.equalsIgnoreCase("repeat"))
                     {
                        if(callReason != null && callReason.equalsIgnoreCase("balance"))
                        {
                      	  SessionObject.INSTANCE.getSession(callID).put("target_menu","A3000_FSA_Bal_Inqry_PP"); 
                          result.put("NextCallFlow","false");
                        }
                        else if (callReason != null && callReason.equalsIgnoreCase("address"))   
                        {
       	                 SessionObject.INSTANCE.getSession(callID).put("target_callflow","A1020_FSA_Employee_Call_Reason_DM"); 
       	                 SessionObject.INSTANCE.getSession(callID).put("target_menu","A3060_FSA_Mailing_Address_PP"); 
       	                 result.put("NextCallFlow","true");  
                        }
                        else if (callReason != null && callReason.equalsIgnoreCase("planinfo"))   
                        {
                      	  SessionObject.INSTANCE.getSession(callID).put("target_menu","A3040_FSA_Plan_Yr_Info_PP"); 
                          result.put("NextCallFlow","false");
                        }
                        else if (callReason != null && callReason.equalsIgnoreCase("claims"))  
                        {
                      	  SessionObject.INSTANCE.getSession(callID).put("target_menu","A3030_FSA_Play_Hsa_DependntCare_PP"); 
                          result.put("NextCallFlow","false");
                        }
                        else
                        {
                      	  SessionObject.INSTANCE.getSession(callID).put("target_menu","A3050_FSA_Last_Reimbursement_PP"); 
                          result.put("NextCallFlow","false");
                        }
                     }
            	     else
            	     {
            	    	 if(retValue != null && retValue.equalsIgnoreCase("agent"))
            	    	 {
                   		  result.put("NextCallFlow","transfer");
                   		  result.put("event_msg","agent ReturnValue"); 
            	    	 }
            	    	 else
            	    	 {
            	    		 if(retValue != null && retValue.equalsIgnoreCase("main_menu"))
            	    		 {	 
            	    		   if(appType != null && appType.equalsIgnoreCase("EB"))
            	    		   {
              	                 SessionObject.INSTANCE.getSession(callID).put("target_callflow","M1000_MemberMenu_DM"); 
              	                 SessionObject.INSTANCE.getSession(callID).put("target_menu","M1000_MemberMenu_DM"); 
              	                 result.put("NextCallFlow","true");
            	    		   }
            	    		   else
            	    		   {
            	                 SessionObject.INSTANCE.getSession(callID).put("target_callflow","A1020_FSA_Employee_Call_Reason_DM"); 
            	                 SessionObject.INSTANCE.getSession(callID).put("target_menu","A1020_FSA_Employee_Call_Reason_DM"); 
            	                 result.put("NextCallFlow","true");
            	    		   }
            	    		 }
            	    		 else
            	    		 { 
                       		  result.put("NextCallFlow","goodbye");
                    		  result.put("event_msg","UnMatched ReturnValue"); 
            	    		 }
            	        }
                    } 
            
            }else 
            {
            	debugLogger.error(loggingCommonFormat + "Unhandled NDM response >"+" ReturnValue "+retValue+" ReturnCode "+retCode+" ReturnInputmode "+state.getString("NDM_ReturnInputmode")+" ReturnKey "+state.getString("NDM_ReturnKey")+" Failurereason "+state.getString("NDM_failurereason")+" ReturnResult "+state.getString("NDM_ReturnResult")+"<");
    		  result.put("NextCallFlow","goodbye");
    		  result.put("event_msg","Unhandled OSDM response ");  
            }
        }catch(Exception exc) // Log Error Info
        {
        	debugLogger.error(loggingCommonFormat + "Encountered exception A3070_FSA_Menu_Options: " + exc.toString() );
        }
return result;
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
