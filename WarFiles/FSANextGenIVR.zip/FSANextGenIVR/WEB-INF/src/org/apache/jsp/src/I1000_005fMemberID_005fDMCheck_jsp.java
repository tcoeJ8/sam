package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import org.apache.log4j.Logger;
import java.util.Date;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class I1000_005fMemberID_005fDMCheck_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception
{
        JSONObject result = new JSONObject();
      	//Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
        Logger debugLogger = Logger.getLogger("IvrAppLogger"); 
        
        String sessionID = state.getString("GVPSessionID").split(";")[0];
        String callID = state.getString("CallUUID").trim();
        Date timeStamp = new Date();
        String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
        boolean isDebugEnabled = false ;

        try{
            String retCode = state.getString("NDM_ReturnCode"); 
            String retValue = state.getString("NDM_ReturnValue");             
            if( SessionObject.INSTANCE.getSession(callID)  !=  null )
             {

               isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
             }

            if (isDebugEnabled)
             {
               debugLogger.debug(loggingCommonFormat + " ");
               debugLogger.debug(loggingCommonFormat + "******************************************");
               debugLogger.debug(loggingCommonFormat + "I1000_MemberID_DMCheck");
               debugLogger.debug(loggingCommonFormat + "ReturnCode: " + retCode);
               debugLogger.debug(loggingCommonFormat + "ReturnValue: " + retValue);
             }                 
            if (retCode != null && retCode.equals("COMMAND"))
            {
                result.put("NextCallFlow","transfer"); 
                result.put("event_msg","COMMAND ReturnCode");
            }
            if (retCode != null && retCode.equals("SUCCESS") || retCode.equals("DTMF"))
            {
    	    	SessionObject.INSTANCE.getSession(callID).put("memberSsn",retValue); 
                SessionObject.INSTANCE.getSession(callID).put("target_menu","I1100_MemberLookup_DA"); 
                result.put("NextCallFlow","false");            
            }           
            	else 
            {
            		debugLogger.error(loggingCommonFormat + "Unhandled NDM response >"+" ReturnValue "+retValue+" ReturnCode "+retCode+" ReturnInputmode "+state.getString("NDM_ReturnInputmode")+" ReturnKey "+state.getString("NDM_ReturnKey")+" Failurereason "+state.getString("NDM_failurereason")+" ReturnResult "+state.getString("NDM_ReturnResult")+"<");           	
                result.put("NextCallFlow","transfer"); 
                result.put("event_msg","Unhandled NDM response");
            }
           }catch(Exception exc) // Log Error Info 
            {
        	   debugLogger.error(loggingCommonFormat + "Encountered exception I1000_MemberID: " + exc.toString() );
            }
    return result;
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
