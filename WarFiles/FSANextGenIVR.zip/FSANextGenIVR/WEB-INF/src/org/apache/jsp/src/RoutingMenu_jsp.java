package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import org.apache.log4j.Logger;
import com.genesyslab.studio.backendlogic.BackendLogManager;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import org.json.JSONException;
import java.lang.*;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class RoutingMenu_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String,String> additionalParams) throws Exception {  
	Logger debugLogger = BackendLogManager.getLogger("debugLogger"); 
 	Logger errorLogger = BackendLogManager.getLogger("errorLogger");	
 	
 	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    String ANI = state.getString("ANI").trim();
    String DNIS = state.getString("DNIS").trim();   
    Date timeStamp = new Date();
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    String debug="";
    String currentDate = "";
    String currentTime = ""; 
    String targetCallflow="";
    String targetMenu="";
	JSONObject result = new JSONObject();
	 boolean isDebugEnabled=false;
	 try {
		 if( SessionObject.INSTANCE.getSession(callID)  !=  null ){ 				
				isDebugEnabled = (Boolean)SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled");				
				if (isDebugEnabled){ 
		    		debugLogger.debug(loggingCommonFormat + " ");
		    		debugLogger.debug(loggingCommonFormat + "******************************************");
		    		debugLogger.debug(loggingCommonFormat + "In Routing Menu Page");		    			    		
		    	}			
				result.put("RoutingFlag","true");
				if("getAttData".equals(targetCallflow)){
					result.put("NextRouting","getAttData.vxml");				
				}
				else if("Coe_1000_Welcome".equals(targetCallflow)){
					result.put("NextRouting","Coe_1000_Welcome.vxml");
				}
				else if("A1000_Welcome".equals(targetCallflow)){
					result.put("NextRouting","A1000_Welcome.vxml");
				}
				else if("A7000_Get_Contract_Number".equals(targetCallflow)){
					result.put("NextRouting","A7000_Get_Contract_Number.vxml");
				}
				else if("A7043_Thanks_And_Wait".equals(targetCallflow)){
					result.put("NextRouting","A7043_Thanks_And_Wait.vxml");
				}
				else if("A2100_Get_Fund_Name".equals(targetCallflow)){
					result.put("NextRouting","A2100_Get_Fund_Name.vxml");
				}
				else if("A5000_Which_Form".equals(targetCallflow)){
					result.put("NextRouting","A5000_Which_Form.vxml");
				}
				else if("A4000_Research_Fund_Intro".equals(targetCallflow)){
					result.put("NextRouting","A4000_Research_Fund_Intro.vxml");
				}
				else if("A4020_Retrieve_Product_Info".equals(targetCallflow)){
					result.put("NextRouting","A4020_Retrieve_Product_Info.vxml");
				}
				else{
					result.put("RoutingFlag","false");
					result.put("NextRouting","A9000_General_Error.vxml");
				}
				if (isDebugEnabled){
					debugLogger.debug(loggingCommonFormat + "Target Routing :"+targetCallflow);
					debugLogger.debug(loggingCommonFormat + "Target Menu :"+targetMenu);
				}				
 			}
 		}	 
	  catch (Exception exc){    		
  		errorLogger.error(loggingCommonFormat + "Encountered exception Routing Menu: " + exc.toString() ); 				
  	} 
    
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
