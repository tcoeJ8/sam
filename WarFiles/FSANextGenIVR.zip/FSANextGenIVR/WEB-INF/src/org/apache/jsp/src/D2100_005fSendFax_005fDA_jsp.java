package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.scansoft.guardian.fsa.service.ServiceManager;
import com.scansoft.guardian.fsa.bean.*;
import com.google.gson.Gson;
import com.pointel.ivr.SessionObject;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class D2100_005fSendFax_005fDA_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception
{
    
     //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
       
    String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    boolean isDebugEnabled = false;
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    String CXIhook = "";
	   
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");		
   	Calendar now = Calendar.getInstance();
   	String currentDate = dateFormat.format(now.getTime());
    JSONObject result = new JSONObject();
    try{
         FaxBenefits info = null;
         String ssn = "";
         String callerType = "";
         String faxNumber = "";
         Policy policy = null;
         if( SessionObject.INSTANCE.getSession(callID)  !=  null )
         {
    	  isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled") );
          ssn = (String) SessionObject.INSTANCE.getSession(callID).get("memberSsn");
          callerType = (String) SessionObject.INSTANCE.getSession(callID).get("callerType");
          policy = (Policy) SessionObject.INSTANCE.getSession(callID).get("policy");
          faxNumber = (String) SessionObject.INSTANCE.getSession(callID).get("faxNumber");
          CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
         }
       
	     if (isDebugEnabled)
	     {
		  debugLogger.debug(loggingCommonFormat + " ");
    	  debugLogger.debug(loggingCommonFormat + "******************************************");
    	  debugLogger.debug(loggingCommonFormat + "In D2100_SendFax_DA");
	     }	

         try
         {      
        	 //Web Service Integration Start
             String groupId = "00245491";
             String dob = policy.getDateOfBirth();
             String coverageType = "M";
             if(callerType != null && callerType.equalsIgnoreCase("dental"))
             {
                 coverageType = "D";
             }             
             if(faxNumber.length() == 10)
             {
                 faxNumber = "91" + faxNumber;
             }
    		 debugLogger.debug(loggingCommonFormat + "Calling Task Execute with :");
    		 debugLogger.debug(loggingCommonFormat + "SSN = " + ssn);
    		 debugLogger.debug(loggingCommonFormat + "groupId = " + groupId);
    		 debugLogger.debug(loggingCommonFormat + "dob = " + dob);
    		 debugLogger.debug(loggingCommonFormat + "coverageType = " + coverageType);
    		 debugLogger.debug(loggingCommonFormat + "faxNumber = " + faxNumber);
 		     JSONObject request = new JSONObject();
	         request.put("taskName", "FaxBenefitsTask");             
	         request.put("memberId", ssn);
	         request.put("groupId", groupId);
	         request.put("dob", dob);
	         request.put("coverageType", coverageType);
	         request.put("faxNumber", faxNumber);
	         if (isDebugEnabled)
 	         {
 	       		debugLogger.debug(loggingCommonFormat +"Send Request as Input: " +request.toString());
 	         }
	         ServiceManager sm = new ServiceManager();
 	         JSONObject jsonResponse = new JSONObject();
 	         jsonResponse = sm.execute(request);
 	         if (isDebugEnabled)
 	         {
 	          debugLogger.debug(loggingCommonFormat +"Get Response from Service:" + jsonResponse.toString());
 	         }
 	   	     if(jsonResponse.has("response"))
 	   	     {
 	   		  JSONObject jsonObj = jsonResponse.getJSONObject("response");
 	   		  JSONObject responseBean = jsonObj.getJSONObject("FaxBenefits");
 	   		  info = new Gson().fromJson(responseBean.toString(), FaxBenefits.class);
 	   		  
 	   	//For Report					
				 if(CXIhook.equals("Y")){
				    	GenerateReport CXIreport  = new GenerateReport();
						JSONObject ivrTransacation = new JSONObject();
						ivrTransacation.put("ENTRY_TIME",currentDate);							
						ivrTransacation.put("DB_LOOKUP","Success");
						CXIreport.addFlow(callID,"D2100_SendFax_DA",ivrTransacation);
				    	}	
 	         }else
 	         {
 	           debugLogger.debug(loggingCommonFormat +"Json Response is wrong");
 	        //For Report					
				 if(CXIhook.equals("Y")){
				    	GenerateReport CXIreport  = new GenerateReport();
						JSONObject ivrTransacation = new JSONObject();
						ivrTransacation.put("ENTRY_TIME",currentDate);							
						ivrTransacation.put("DB_LOOKUP","Failure");
						ivrTransacation.put("FAILURE_REASON","dbGet");
						CXIreport.addFlow(callID,"D2100_SendFax_DA",ivrTransacation);
				    	}	
				  result.put("NextCallFlow","transfer");
 	   	     }	// Web Service Integration end
     	 }
     	 catch(Exception ex)
     	 {
     		debugLogger.error(loggingCommonFormat + "Task Exception in FaxBenefits Execute", ex);
         	SessionObject.INSTANCE.getSession(callID).put("failureReason","dbPut");
            result.put("NextCallFlow","transfer");
            result.put("event_msg","Task Exception in FaxBenefits Execute"); 
     	 }
         if(info != null)
         {
             SessionObject.INSTANCE.getSession(callID).put("failureReason","");
             if(isDebugEnabled)
             {
            	debugLogger.debug(loggingCommonFormat + "EIS Submit Fax Returned Success");
             }
             if(info.getStatus().isSuccessful())
             {
            	debugLogger.debug(loggingCommonFormat + "Fax Send Successful");
         	    SessionObject.INSTANCE.getSession(callID).put("target_menu","D3000_ReceiveFax_PP"); 
         	    result.put("NextCallFlow","false");
             }
        		 debugLogger.debug(loggingCommonFormat + "Fax Send FAILED");
          }
          result.put("NextCallFlow","transfer");
          result.put("event_msg","transfer"); 	
       }catch(Exception ex) // Log Error Info 
       {
    	   debugLogger.error(loggingCommonFormat + "should never reach here");
        result.put("NextCallFlow","transfer");
        result.put("event_msg","should never reach here");            
       }			
    return result;   
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write(' ');
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
