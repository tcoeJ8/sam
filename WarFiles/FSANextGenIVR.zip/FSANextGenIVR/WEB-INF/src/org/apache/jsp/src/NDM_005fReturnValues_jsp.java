package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import java.util.Calendar;
import java.util.TimeZone;
import com.guardian.cct.reporting.*;
import org.apache.log4j.Logger;
import com.genesyslab.studio.backendlogic.BackendLogManager;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import java.util.Date;
import java.util.TimeZone;
import java.util.Calendar;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class NDM_005fReturnValues_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {    
    
	Logger debugLogger = BackendLogManager.getLogger("debugLogger"); 
 	Logger errorLogger = BackendLogManager.getLogger("errorLogger");	 
 	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    String ANI = state.getString("ANI").trim();
    String DNIS = state.getString("DNIS").trim();
    Date timeStamp = new Date();
    String Logger_commonVar = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    String debug="";
    JSONObject result = new JSONObject();
    boolean isDebugEnabled=false;
    isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
	if (isDebugEnabled){
    debugLogger.debug(Logger_commonVar + "");
    debugLogger.debug(Logger_commonVar + "******************************************");
    debugLogger.debug(Logger_commonVar + "In NDM_ReturnValues");
	}
    String NDM_ndmReturnCode="";
    String NDM_ndmReturnValue="";
    String NDM_ndmInputMode="";
    String NDM_ndmFailureReason="";
    String NDM_ReturnResult="";
	
    Double NDM_confidencescore=0.0;
    int NDM_noinputs=0;
    int NDM_nomatches=0;
    String NDM_dm_root_status="";
	
	// Get return values of NDM module
   	try {
       	NDM_ndmReturnCode = state.getString("NDM_ReturnCode");
		NDM_ndmReturnValue = state.getString("NDM_ReturnValue");
     	NDM_ndmInputMode = state.getString("NDM_ReturnInputmode");
		NDM_ndmFailureReason = state.getString("NDM_failurereason");	 
		NDM_ReturnResult = state.getString("NDM_ReturnResult");
		String StateName=state.getString("StateName");
		NDM_confidencescore = state.getDouble("NDM_confidencescore");
		NDM_noinputs = state.getInt("NDM_noinputs");
		NDM_nomatches = state.getInt("NDM_nomatches");	 
		NDM_dm_root_status = state.getString("NDM_dm_root_status");
		if (isDebugEnabled){
		 debugLogger.debug(Logger_commonVar +"NDM_ndmInputMode----->"+NDM_ndmInputMode);
		 debugLogger.debug(Logger_commonVar +"NDM_ndmFailureReason----->"+NDM_ndmFailureReason);
		 debugLogger.debug(Logger_commonVar +"NDM_ReturnResult----->"+NDM_ReturnResult);
		 debugLogger.debug(Logger_commonVar +"NDM_confidencescore----->"+NDM_confidencescore);
		 debugLogger.debug(Logger_commonVar +"NDM_noinputs----->"+NDM_noinputs);
		 debugLogger.debug(Logger_commonVar +"NDM_nomatches----->"+NDM_nomatches);
		 debugLogger.debug(Logger_commonVar +"NDM_dm_root_status----->"+NDM_dm_root_status);
		}
		 SessionObject.INSTANCE.getSession(callID).put("NDM_ReturnCode",NDM_ndmReturnCode);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_ReturnValue",NDM_ndmReturnValue);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_InputMode",NDM_ndmInputMode);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_confidencescore",NDM_confidencescore);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_noinputs",NDM_noinputs);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_nomatches",NDM_nomatches);
		 CallflowEndReport dmReportEnd=new CallflowEndReport();
		 dmReportEnd.endCallflowReport(callID,StateName);//Sarg Report End
		
   	} catch(Exception ex) {
   		errorLogger.error(Logger_commonVar + "Encountered exception in NDM_ReturnValues: " + ex.getMessage() );
   	}
		
	return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
