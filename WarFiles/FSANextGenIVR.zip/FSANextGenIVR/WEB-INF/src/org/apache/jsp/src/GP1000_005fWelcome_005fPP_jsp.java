package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import com.guardian.cct.reporting.*;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class GP1000_005fWelcome_005fPP_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception 
{

    JSONObject result = new JSONObject();
    JSONArray promptList = new JSONArray();
  //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
    Logger debugLogger = Logger.getLogger("IvrAppLogger"); 
    
    
    String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");    				
	Calendar now = Calendar.getInstance();
	String entryTime = dateFormat.format(now.getTime());
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";

    boolean isDebugEnabled = false ;

    try {
    	 String ani = "";
    	 String dnis = "";
    	 ReportCall reportCall = null;
    	 String CXIhook = "";
    	
        if( SessionObject.INSTANCE.getSession(callID)  !=  null )
         {
            ani = (String) SessionObject.INSTANCE.getSession(callID).get("ANI");
            dnis = (String) SessionObject.INSTANCE.getSession(callID).get("DNIS");
            isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
            reportCall =(ReportCall)SessionObject.INSTANCE.getSession(callID).get("ReportCallObj");	
            CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
         }
        if (isDebugEnabled)
         {
            debugLogger.debug(loggingCommonFormat + " ");
            debugLogger.debug(loggingCommonFormat + "******************************************");
            debugLogger.debug(loggingCommonFormat + "GP1000_Welcome_PP");
         }   
            reportCall.getReportCallData().put("ANI", ani);	
            reportCall.getReportCallData().put("DNIS", dnis);
            
            if(CXIhook.equals("Y"))
            {
            	GenerateReport CXIreport  = new GenerateReport();
        	    JSONObject ivrTransacation = new JSONObject();
        		ivrTransacation.put("ENTRY_TIME",entryTime);
        		ivrTransacation.put("ANI",ani); 
        		ivrTransacation.put("DNIS",dnis);
        	    CXIreport.addFlow(callID,"GP1000_Welcome_PP", ivrTransacation);
            }
            
       if ((ani==null)||(ani.trim().length()==0))
        {
           debugLogger.info(loggingCommonFormat + "ANI not available");
        }
       else
        {
           debugLogger.info(loggingCommonFormat + "ANI invalid >"+ani+"<");
        }
         // Prompt and Type as input
          promptList.put("audio,GP1000_Welcome_ini.ulaw");
          result.put("PromptList",promptList);   
          SessionObject.INSTANCE.getSession(callID).put("target_menu", "GP2000_CallerType_DM");
          result.put("NextCallFlow","false");
          result.put("StateName", "GP1000_Welcome");
      } catch(Exception exc)  // Log Error Info 
      {
    	  debugLogger.error(loggingCommonFormat + "Encountered exception in GP1000_Welcome_PP : " + exc.toString() ); // Have to change
      }
    return result;
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
