package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.scansoft.guardian.fsa.service.ServiceManager;
import com.scansoft.guardian.fsa.bean.*;
import com.google.gson.Gson;
import com.pointel.ivr.SessionObject;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import java.util.Date;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.ArrayList;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class A2060_005fFSA_005fPolicyLookup_005fDA_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception
{
    
     //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
       
    String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");		
   	Calendar now = Calendar.getInstance();
   	String currentDate = dateFormat.format(now.getTime());

    boolean isDebugEnabled = false;
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    JSONObject result = new JSONObject();
    String CXIhook = "";
    try{
    	ArrayList balEnqArrList = new ArrayList();
    	ArrayList claimStatusArrList = new ArrayList();
    	ArrayList planYearInfoArrList = new ArrayList();
    	ArrayList lastReimbInfArrList = new ArrayList();
        String callReason = "";
        String ssn = "";
        if( SessionObject.INSTANCE.getSession(callID)  !=  null )
        {
    	 isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled") );
    	 callReason = (String)SessionObject.INSTANCE.getSession(callID).get("callReason");
    	 ssn = (String)SessionObject.INSTANCE.getSession(callID).get("ssn");
    	 CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
        }
       
	    if (isDebugEnabled)
	    {
		 debugLogger.debug(loggingCommonFormat + " ");
    	 debugLogger.debug(loggingCommonFormat + "******************************************");
    	 debugLogger.debug(loggingCommonFormat + "In A2060_FSA_PolicyLookup");
	    }	
	    try
	    { 
	    	// Database Integration start
	    	JSONObject request = new JSONObject();
        	request.put("daoClass", "FSATransactionManager");;
        	request.put("ssn", ssn); 
        	
			if(callReason != null && callReason.equalsIgnoreCase("balance"))  
	          request.put("methodName","getBananceEnquiry"); 
			
            else if(callReason != null && callReason.equalsIgnoreCase("claims")) 
              request.put("methodName","getClaimStatus"); 
			
    	    else if(callReason != null && callReason.equalsIgnoreCase("planinfo")) 
           	  request.put("methodName","getPlanYearInfo");
			
    	    else    
           	 request.put("methodName","getLastReimurseInfo");
			
			if (isDebugEnabled)
       	    {
			 debugLogger.debug(loggingCommonFormat +"Send Request as Input: " +request.toString());
            }
			
			ServiceManager sm = new ServiceManager();
        	JSONObject jsonResponse = new JSONObject();
        	jsonResponse = sm.execute(request);
        	if (isDebugEnabled)
        	{
			 debugLogger.debug(loggingCommonFormat +"Get Response from Service:" + jsonResponse.toString());
        	}
        	//Database Integration end
			if(jsonResponse.has("response"))
			{
			    JSONObject jsonObj = jsonResponse.getJSONObject("response");
			   //For Report					
				 if(CXIhook.equals("Y")){
				    	GenerateReport CXIreport  = new GenerateReport();
						JSONObject ivrTransacation = new JSONObject();
						ivrTransacation.put("ENTRY_TIME",currentDate);							
						ivrTransacation.put("DB_LOOKUP","Success");
						CXIreport.addFlow(callID,"A2060_FSA_PolicyLookup",ivrTransacation);
				    	}	
			    if(callReason != null && callReason.equalsIgnoreCase("balance"))
	    	    {			    	  
			    	JSONArray arrayResponse = jsonObj.getJSONArray("balEnqArrList");
					for(int i=0 ; i<arrayResponse.length();i++)
					  balEnqArrList.add(arrayResponse.getString(i));
              	    SessionObject.INSTANCE.getSession(callID).put("balEnqArrList",balEnqArrList);
                	SessionObject.INSTANCE.getSession(callID).put("target_menu","A3000_FSA_Bal_Inqry_PP"); 
                    result.put("NextCallFlow","false");
	    	    }
			    else if(callReason != null && callReason.equalsIgnoreCase("claims"))
	            {  
			    	JSONArray arrayResponse = jsonObj.getJSONArray("claimStatusArrList");								    	
					for(int i=0 ; i<arrayResponse.length();i++)
						claimStatusArrList.add(arrayResponse.getString(i));
              	    SessionObject.INSTANCE.getSession(callID).put("claimStatusArrList",claimStatusArrList);
                	SessionObject.INSTANCE.getSession(callID).put("target_menu","A3010_FSA_Claim_Stat_PP"); 
                    result.put("NextCallFlow","false");                    
	            }
			    else if(callReason != null && callReason.equalsIgnoreCase("planinfo"))
			    { 
			    	JSONArray arrayResponse = jsonObj.getJSONArray("planYearInfoArrList");					
					for(int i=0 ; i<arrayResponse.length();i++)
						planYearInfoArrList.add(arrayResponse.getString(i));
              	    SessionObject.INSTANCE.getSession(callID).put("planYearInfoArrList",planYearInfoArrList);
                	SessionObject.INSTANCE.getSession(callID).put("target_menu","A3040_FSA_Plan_Yr_Info_PP"); 
                    result.put("NextCallFlow","false");
			    }
			    else 
	            { 
			    	JSONArray arrayResponse = jsonObj.getJSONArray("lastReimbInfArrList");					
					for(int i=0 ; i<arrayResponse.length();i++)
						lastReimbInfArrList.add(arrayResponse.getString(i));
              	    SessionObject.INSTANCE.getSession(callID).put("lastReimbInfArrList",lastReimbInfArrList);
                	SessionObject.INSTANCE.getSession(callID).put("target_menu","A3050_FSA_Last_Reimbursement_PP"); 
                    result.put("NextCallFlow","false"); 
	            }
       	   }
		   else
           {
			   if (isDebugEnabled)
        	  debugLogger.debug(loggingCommonFormat +"Json Response is wrong");
			 //For Report					
				 if(CXIhook.equals("Y")){
				    	GenerateReport CXIreport  = new GenerateReport();
						JSONObject ivrTransacation = new JSONObject();
						ivrTransacation.put("ENTRY_TIME",currentDate);							
						ivrTransacation.put("DB_LOOKUP","Failure");
						ivrTransacation.put("FAILURE_REASON","dbGet");
						CXIreport.addFlow(callID,"A2060_FSA_PolicyLookup",ivrTransacation);
				    	}	
				 result.put("NextCallFlow","terminate");
		   } 
			
	    }catch(Exception e)
    	{
	    	debugLogger.error(loggingCommonFormat + "Exception occurred while trying to fetch information");
		}
    }catch(Exception ex) // Log Error Info 
    {
    	debugLogger.error(loggingCommonFormat + "should never reach here");
        result.put("NextCallFlow","terminate");
        result.put("event_msg","should never reach here");
            
    }			
    return result;   
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write(' ');
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
