package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;
import org.apache.log4j.Logger;

public final class NDM_005fProperties_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
        
	JSONObject result = new JSONObject();	
	
	Logger logger = LogManager.getLogger("CUSTOM_LOGGER");
	String NDM_sessionID = state.getString("GVPSessionID").split(";")[0];
    String NDM_callID = state.getString("CallUUID").trim();	
    String NDM_logInfo = " {" + NDM_sessionID + "}, " + NDM_callID + ",";
	
	logger.debug(NDM_logInfo + "");
	logger.debug(NDM_logInfo + "******************************************");
	logger.debug(NDM_logInfo + "In NDM_Properties");
	
	String NDM_appDir = "";
	
	try {
		
		NDM_appDir = getServletConfig().getServletContext().getRealPath("Config/im_ndmprops.properties");
	
		String NDM_propFilePath =  NDM_appDir;
		File propFile = new File(NDM_propFilePath);	
		
		String NDM_strCompleteName = "";	
		String NDM_strSessionStart = "";
		String NDM_strSessionEnd = "";
		String NDM_strWebServerName = "";
				
		FileInputStream configStream = new FileInputStream(propFile);
		Properties proFlexxgate = new Properties();
		proFlexxgate.load(configStream);
	
		//Get module name
		String NDM_dmName = state.getString("NDM_dmname"); //dmname 
		
		//Get NDM URL, Directory URL, Application Prompt Script Directory and Baseline Prompt directory from Properties file
		String NDM_NDMUrl = proFlexxgate.getProperty("NDM_URL");
		String NDM_DirURL = proFlexxgate.getProperty("Dir_URL"); 
		String User_IP_Port = proFlexxgate.getProperty("USER_IP_PORT");
		String NDM_ApplicationPromptScriptDir = proFlexxgate.getProperty("NDM_ApplicationPromptScriptDir");
		String NDM_BaselinePromptDir = proFlexxgate.getProperty("NDM_BaselinePromptDir");
		
		//Set Browser Ip for NDM Session
		result.put("browserip", proFlexxgate.getProperty("NDM_BrowserIp"));
		result.put("logging_base_path", proFlexxgate.getProperty("NDM_LoggingBasePath"));
		
		//Set NDM URL
		NDM_strCompleteName = "http://" + NDM_NDMUrl + "/ndm-core/" + NDM_dmName;
		result.put("NDM_Web_URL", NDM_strCompleteName);
		
		//set NDM Session start URL
		NDM_strSessionStart = "http://" + NDM_NDMUrl + "/ndm-core/sessionstart";
		result.put("NDM_Web_URL_SS", NDM_strSessionStart);
		
		//set NDM Session end URL
		NDM_strSessionEnd = "http://" + NDM_NDMUrl + "/ndm-core/sessionend";
		result.put("NDM_Web_URL_SE", NDM_strSessionEnd);
		
		//Log NDM URL and Browser IP
		logger.debug(NDM_logInfo + "NDM_Web_URL - - " + NDM_strCompleteName);
		logger.debug(NDM_logInfo + "NDM_BrowserIp - - " + proFlexxgate.getProperty("NDM_BrowserIp"));
		logger.debug(NDM_logInfo + "NDM_LoggingBasePath - - " + proFlexxgate.getProperty("NDM_LoggingBasePath"));
		
		String NDM_NDMGrammarDir = "";
		String NDM_NDMPromptDir = "";	
		String NDM_language ="";
		
		NDM_language = state.getString("APP_LANGUAGE");
	
		//Log Language
		logger.debug(NDM_logInfo + "SCG_Glbl_language - - "+NDM_language);
		
		//Check language whether it is english or spanish and set Prompts & Grammars directory for appropriate language
		if (NDM_language != null && NDM_language.equalsIgnoreCase("en-US")){
			
			logger.debug(NDM_logInfo + "NDM_language - - en-US");
	
			NDM_NDMPromptDir = proFlexxgate.getProperty("NDM_PromptDir");
			NDM_NDMGrammarDir = proFlexxgate.getProperty("NDM_GrammarDir");			
			
			String NDM_baseCompleteEnglish = "http://" +User_IP_Port + NDM_BaselinePromptDir;
			String NDM_promptDirEnglish = "http://" +User_IP_Port + NDM_NDMPromptDir;
			String NDM_grammarDirEnglish = "http://" + User_IP_Port + NDM_NDMGrammarDir;
			
			NDM_ApplicationPromptScriptDir = "http://" + User_IP_Port +NDM_ApplicationPromptScriptDir +"/en-US";
			NDM_baseCompleteEnglish = NDM_baseCompleteEnglish +"/en-US";
			result.put("baselinepromptsdirectory", NDM_baseCompleteEnglish);
			result.put("applicationgrammarsdirectory", NDM_grammarDirEnglish);					
			result.put("applicationpromptsdirectory", NDM_promptDirEnglish); 
			//Log baselinepromptsdirectory
			logger.debug(NDM_logInfo + "baselinepromptsdirectory: "+ NDM_baseCompleteEnglish);						
			logger.debug(NDM_logInfo + "NDM_ApplicationPromptScriptDir - - "+NDM_ApplicationPromptScriptDir);
			logger.debug(NDM_logInfo + "NDM_Properties_promptDirEnglish - - "+NDM_promptDirEnglish);
			logger.debug(NDM_logInfo + "NDM_Properties_grammarDirEnglish - - "+NDM_grammarDirEnglish);
			
			
		} else {
			
			logger.debug(NDM_logInfo + "NDM_language - - es-US");
	
			NDM_NDMPromptDir = proFlexxgate.getProperty("NDM_PromptDir_SP");
			NDM_NDMGrammarDir = proFlexxgate.getProperty("NDM_GrammarDir_SP");
			
			String NDM_baseCompleteSpanish = "http://" + NDM_DirURL + NDM_BaselinePromptDir;
			String NDM_promptDirSpanish = "http://" + NDM_DirURL + NDM_NDMPromptDir;
			String NDM_grammarDirSpanish = "http://" + NDM_DirURL + NDM_NDMGrammarDir;

			NDM_ApplicationPromptScriptDir = "http://" + NDM_DirURL + NDM_ApplicationPromptScriptDir +"/es-US";
			NDM_baseCompleteSpanish = NDM_baseCompleteSpanish +"/es-US";
			
			result.put("baselinepromptsdirectory", NDM_baseCompleteSpanish);
			result.put("applicationgrammarsdirectory",  NDM_grammarDirSpanish);					
			result.put("applicationpromptsdirectory", NDM_promptDirSpanish);
			
			//Log baselinepromptsdirectory
			logger.debug(NDM_logInfo + "baselinepromptsdirectory: "+ NDM_baseCompleteSpanish);
			logger.debug(NDM_logInfo + "NDM_ApplicationPromptScriptDir - - "+NDM_ApplicationPromptScriptDir);
			logger.debug(NDM_logInfo + "NDM_promptDirSpanish - - "+NDM_promptDirSpanish);
 			logger.debug(NDM_logInfo + "NDM_grammarDirSpanish - - "+NDM_grammarDirSpanish);
		}	
	
		result.put("applicationpromptscriptdirectory", NDM_ApplicationPromptScriptDir);
			
	
	} catch (FileNotFoundException e){ // Write error info
		logger.error(NDM_logInfo + "NDM Read Properties FileNotFoundException :  " + e.getMessage());
	} catch (IOException e){	
		logger.error(NDM_logInfo + "NDM Read Properties IOException :  " + e.getMessage());
	} catch (Exception e){	
		logger.error(NDM_logInfo + "NDM Read Properties Exception :  " + e.getMessage());			
	}
	
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write("\r\n\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
