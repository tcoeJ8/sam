package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class FSA_005fNDM_005fProperties_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
        
	JSONObject result = new JSONObject();	
	
	Logger debugLogger = Logger.getLogger("IvrAppLogger");  
	
  	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    boolean isDebugEnabled = false ;
	
	debugLogger.debug(loggingCommonFormat + "");
	debugLogger.debug(loggingCommonFormat + "******************************************");
	debugLogger.debug(loggingCommonFormat + "In NDM_Properties");
	
	String NDM_language ="";
	
	try {
		if( SessionObject.INSTANCE.getSession(callID)  !=  null ){
			isDebugEnabled = java.lang.Boolean.valueOf((String)SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
			 
			NDM_language = (String)SessionObject.INSTANCE.getSession(callID).get("language");  
		}
		
		String NDM_strCompleteName = "";	
		String NDM_strSessionStart = "";
		String NDM_strSessionEnd = "";
		String NDM_strWebServerName = "";
		
		String NDM_NDMUrl = "";
		String NDM_DirURL = "";		
		String NDM_ApplicationPromptScriptDir = "";
		String NDM_BaselinePromptDir = "";
		String browserip = "";		
		String NDM_PromptDir = "";
		String NDM_GrammarDir = "";
		String NDM_SPPromptDir ="";
		String NDM_SPGrammarDir ="";				
	
	
		//Get module name
		String NDM_dmName = state.getString("NDM_dmname"); //dmname 
		
		//Get NDM URL, Directory URL, Application Prompt Script Directory and Baseline Prompt directory from Properties file
		if( SessionObject.INSTANCE.getSession(callID)  !=  null ){ 	
			 NDM_NDMUrl = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_NDMUrl");
			 NDM_DirURL = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_DirURL");		
			 NDM_ApplicationPromptScriptDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_ApplicationPromptScriptDir");
			 NDM_BaselinePromptDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_BaselinePromptDir");
			 browserip = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_BrowserIp");			
			 NDM_PromptDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_PromptDir");
			 NDM_GrammarDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_GrammarDir");
			 NDM_SPPromptDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_SPPromptDir");
			 NDM_SPGrammarDir = (String)SessionObject.INSTANCE.getSession(callID).get("NDM_SPGrammarDir");
		}
		//Set Browser Ip for NDM Session
		result.put("NDM_BrowserIp", browserip);
		//result.put("NDM_LoggingBasePath", proFlexxgate.getProperty("NDM_LoggingBasePath"));
		
		//Set NDM URL
		NDM_strCompleteName = "http://" + NDM_NDMUrl + "/ndm-core/" + NDM_dmName;
		result.put("NDM_Web_URL", NDM_strCompleteName);
		
		//set NDM Session start URL
		NDM_strSessionStart = "http://" + NDM_NDMUrl + "/ndm-core/sessionstart";
		result.put("NDM_Web_URL_SS", NDM_strSessionStart);
		
		//set NDM Session end URL
		NDM_strSessionEnd = "http://" + NDM_NDMUrl + "/ndm-core/sessionend";
		result.put("NDM_Web_URL_SE", NDM_strSessionEnd);
		
		//Log NDM URL and Browser IP
		debugLogger.debug(loggingCommonFormat + "NDM_Web_URL - - " + NDM_strCompleteName);
		debugLogger.debug(loggingCommonFormat + "NDM_BrowserIp - - " + browserip);
		
		
	
		//Log Language
		debugLogger.debug(loggingCommonFormat + "FSA_Language - - "+NDM_language);
		
		//Check language whether it is english or spanish and set Prompts & Grammars directory for appropriate language
		if (NDM_language != null && NDM_language.equalsIgnoreCase("en-US")){
			
			debugLogger.debug(loggingCommonFormat + "NDM_language - - en-US");
			String NDM_baseCompleteEnglish = "http://" +NDM_DirURL + NDM_BaselinePromptDir;
			String NDM_promptDirEnglish = "http://" +NDM_DirURL + NDM_PromptDir; //changed
			String NDM_grammarDirEnglish = "http://" + NDM_DirURL + NDM_GrammarDir; //changed
			
			NDM_ApplicationPromptScriptDir = "http://" + NDM_DirURL +NDM_ApplicationPromptScriptDir +"/en-US";
			NDM_baseCompleteEnglish = NDM_baseCompleteEnglish +"/en-US";
			result.put("baselinepromptsdirectory", NDM_baseCompleteEnglish);
			result.put("applicationgrammarsdirectory", NDM_grammarDirEnglish);					
			result.put("applicationpromptsdirectory", NDM_promptDirEnglish); 
			//Log baselinepromptsdirectory
			debugLogger.debug(loggingCommonFormat + "baselinepromptsdirectory: "+ NDM_baseCompleteEnglish);						
			debugLogger.debug(loggingCommonFormat + "NDM_ApplicationPromptScriptDir - - "+NDM_ApplicationPromptScriptDir);
			debugLogger.debug(loggingCommonFormat + "NDM_Properties_promptDirEnglish - - "+NDM_promptDirEnglish);
			debugLogger.debug(loggingCommonFormat + "NDM_Properties_grammarDirEnglish - - "+NDM_grammarDirEnglish);
			
			result.put("lang","en-US");
		} else {
			
			debugLogger.debug(loggingCommonFormat + "NDM_language - - es-US");
	
			String NDM_baseCompleteSpanish = "http://" + NDM_DirURL + NDM_BaselinePromptDir;
			String NDM_promptDirSpanish = "http://" + NDM_DirURL + NDM_SPPromptDir; //changed
			String NDM_grammarDirSpanish = "http://" + NDM_DirURL + NDM_SPGrammarDir; //changed

			NDM_ApplicationPromptScriptDir = "http://" + NDM_DirURL + NDM_ApplicationPromptScriptDir +"/es-US";
			NDM_baseCompleteSpanish = NDM_baseCompleteSpanish +"/es-US";
			
			result.put("baselinepromptsdirectory", NDM_baseCompleteSpanish);
			result.put("applicationgrammarsdirectory",  NDM_grammarDirSpanish);					
			result.put("applicationpromptsdirectory", NDM_promptDirSpanish);
			
			//Log baselinepromptsdirectory
			debugLogger.debug(loggingCommonFormat + "baselinepromptsdirectory: "+ NDM_baseCompleteSpanish);
			debugLogger.debug(loggingCommonFormat + "NDM_ApplicationPromptScriptDir - - "+NDM_ApplicationPromptScriptDir);
			debugLogger.debug(loggingCommonFormat + "NDM_promptDirSpanish - - "+NDM_promptDirSpanish);
 			debugLogger.debug(loggingCommonFormat + "NDM_grammarDirSpanish - - "+NDM_grammarDirSpanish);
 			result.put("lang","es-US");
		}	
	
		result.put("applicationpromptscriptdirectory", NDM_ApplicationPromptScriptDir);
		
		String NDM_collectionInitialPrompt = state.getString("NDM_collection_initialprompt");
		
		if (isDebugEnabled ){
			debugLogger.debug(loggingCommonFormat+ "dmname - NDM_Type: "+ NDM_dmName);						
			debugLogger.debug(loggingCommonFormat + "initial prompt - NDM_collection_initialprompt: "+ NDM_collectionInitialPrompt);
		}
		
		result.put("ndm_type",NDM_dmName);
		
		String maModule = "";
		int startPosition = 0;
		int endPosition = NDM_collectionInitialPrompt.indexOf(".");
		maModule = NDM_collectionInitialPrompt.substring(0,endPosition);
		if(maModule.contains("_")){
			endPosition = maModule.indexOf("_");
			if(endPosition > 7){
			
				startPosition = endPosition - 6;
			}
		}
		
		if(endPosition > 7){
			
			startPosition = endPosition - 6;
		}	
		maModule = maModule.substring(startPosition,endPosition);
		
		if (isDebugEnabled ){
			debugLogger.debug(loggingCommonFormat+ "Module is:  "+ maModule);
		}
		
		result.put("NDM_dmname",maModule);
		result.put("NDM_Main_Module",maModule);
			
	
	} catch (Exception e){	
		debugLogger.error(loggingCommonFormat + "NDM Read Properties Exception :  " + e.getMessage());			
	}
	
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write("\r\n\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
