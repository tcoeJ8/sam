package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import java.util.Calendar;
import java.util.TimeZone;
import com.guardian.cct.reporting.*;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.Calendar;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class FSA_005fNDM_005fReturnValues_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {    
    
	JSONObject result = new JSONObject();
	
    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
	
  	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");		
   	Calendar now = Calendar.getInstance();
   	String currentDate = dateFormat.format(now.getTime());	
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    boolean isDebugEnabled = false ;
    CallflowEndReport dmReportEnd = null;
	
    if( SessionObject.INSTANCE.getSession(callID)  !=  null ){
		isDebugEnabled = java.lang.Boolean.valueOf((String)SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
		dmReportEnd = (CallflowEndReport)SessionObject.INSTANCE.getSession(callID).get("callflowEndReportObj");
    }
    
	if (isDebugEnabled){
    	debugLogger.debug(loggingCommonFormat + "");
   	 	debugLogger.debug(loggingCommonFormat + "******************************************");
   	 	debugLogger.debug(loggingCommonFormat + "In NDM_ReturnValues");
	}
    String NDM_ReturnCode="";
    String NDM_ReturnValue="";
    String NDM_InputMode="";
    String NDM_FailureReason="";
    String NDM_ReturnResult="";
	
    Double NDM_confidencescore=0.0;
    int NDM_noinputs=0;
    int NDM_nomatches=0;
    String NDM_dm_root_status="";
	
	// Get return values of NDM module
   	try {
       	
   		NDM_ReturnCode = state.getString("NDM_ReturnCode");
		NDM_ReturnValue = state.getString("NDM_ReturnValue");
     	NDM_InputMode = state.getString("NDM_ReturnInputmode");
		NDM_FailureReason = state.getString("NDM_failurereason");	 
		NDM_ReturnResult = state.getString("NDM_ReturnResult");
		String StateName=state.getString("StateName");
		NDM_confidencescore = state.getDouble("NDM_confidencescore");
		NDM_noinputs = state.getInt("NDM_noinputs");
		NDM_nomatches = state.getInt("NDM_nomatches");	 
		NDM_dm_root_status = state.getString("NDM_dm_root_status");
		
		if (isDebugEnabled){
		 
			debugLogger.debug(loggingCommonFormat +"NDM_ReturnCode----->"+NDM_ReturnCode);
			debugLogger.debug(loggingCommonFormat +"NDM_ReturnValue----->"+NDM_ReturnValue);
			debugLogger.debug(loggingCommonFormat +"NDM_InputMode----->"+NDM_InputMode);
		 	debugLogger.debug(loggingCommonFormat +"NDM_FailureReason----->"+NDM_FailureReason);
			debugLogger.debug(loggingCommonFormat +"NDM_ReturnResult----->"+NDM_ReturnResult);
		 	debugLogger.debug(loggingCommonFormat +"NDM_confidencescore----->"+NDM_confidencescore);
		 	debugLogger.debug(loggingCommonFormat +"NDM_noinputs----->"+NDM_noinputs);
			debugLogger.debug(loggingCommonFormat +"NDM_nomatches----->"+NDM_nomatches);
		 	debugLogger.debug(loggingCommonFormat +"NDM_dm_root_status----->"+NDM_dm_root_status);
		}
		 SessionObject.INSTANCE.getSession(callID).put("NDM_ReturnCode",NDM_ReturnCode);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_ReturnValue",NDM_ReturnValue);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_InputMode",NDM_InputMode);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_confidencescore",NDM_confidencescore);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_noinputs",NDM_noinputs);
		 SessionObject.INSTANCE.getSession(callID).put("NDM_nomatches",NDM_nomatches); 
		 // Need to add for AppSession FailureReason
		 SessionObject.INSTANCE.getSession(callID).put("FailureReason",NDM_FailureReason); 
		 SessionObject.INSTANCE.getSession(callID).put("dmRootStatus",NDM_dm_root_status); 
				 
		 String CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
		 if(CXIhook.equals("Y")){
		    	GenerateReport CXIreport  = new GenerateReport();
				JSONObject ivrTransacation = new JSONObject();
				ivrTransacation.put("ENTRY_TIME",currentDate);
				ivrTransacation.put("RETURN_CODE",NDM_ReturnCode);
				ivrTransacation.put("RETURN_VALUE",NDM_ReturnValue);
				ivrTransacation.put("INPUT_MODE",NDM_InputMode);
				ivrTransacation.put("CONFIDENCE_SCORE",""+NDM_confidencescore);
				ivrTransacation.put("NO_INPUT_COUNT",""+NDM_noinputs);
				ivrTransacation.put("NO_MATCHES_COUNT","" +NDM_nomatches);
				ivrTransacation.put("INITIAL_PROMPT",state.getString("collection_initialprompt")); 			
				CXIreport.addFlow(callID,StateName,ivrTransacation);
		    	}	
		 
		 dmReportEnd.endCallflowReport(callID,StateName);//Sarg Report End
		 
		 if("COMMAND".equals(NDM_ReturnCode)){
			 
			 if (isDebugEnabled)
				 debugLogger.debug(loggingCommonFormat +"Command----->"+NDM_ReturnValue);
			 
			 if("dispatcher".equals(NDM_ReturnValue)){
				 
				 result.put("NDM_goto","1");
				 result.put("event_msg","dispatcher");
			 }else{
				 result.put("NDM_goto","3");
				 if (isDebugEnabled)
				 	debugLogger.debug(loggingCommonFormat +"Command----->"+NDM_ReturnValue + "< No global behavior defined");
			 }
		 }else if("ERROR".equals(NDM_ReturnCode)){
			
			 debugLogger.error(loggingCommonFormat + "Error " + NDM_FailureReason);
			 result.put("NDM_goto","2");
			 result.put("event_msg",NDM_FailureReason); 
		 }else{
			 if("SUCCESS".equals(NDM_ReturnCode) || "FAILURE".equals(NDM_ReturnCode)|| "DTMF".equals(NDM_ReturnCode))
			 	result.put("NDM_goto","3");
			 else{
				 debugLogger.error(loggingCommonFormat + "NDM Unknown return values >" + NDM_ReturnCode + "< >" + NDM_ReturnValue + "<");
				 result.put("NDM_goto","2"); 
				 result.put("event_msg",NDM_ReturnValue);
			 }
		 }
		
   	} catch(Exception ex) {
   		debugLogger.error(loggingCommonFormat + "Encountered exception in NDM_ReturnValues: " + ex.getMessage() );
   	}
		
	return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
