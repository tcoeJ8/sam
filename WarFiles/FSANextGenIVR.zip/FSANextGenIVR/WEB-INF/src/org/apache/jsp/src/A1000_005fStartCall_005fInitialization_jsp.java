package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import com.guardian.cct.reporting.*;
import com.pointel.ivr.util.*;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import com.scansoft.guardian.fsa.init.Controller;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class A1000_005fStartCall_005fInitialization_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
 
    
    JSONObject result = new JSONObject();
   
    //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
   
 	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    String ANI = state.getString("ANI").trim();
    String DNIS = state.getString("DNIS").trim();
    Date timeStamp = new Date();
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");    				
	Calendar now = Calendar.getInstance();
	String currentDate = dateFormat.format(now.getTime());
	String currentTime = timeFormat.format(now.getTime());
	String entryTime=currentDate+currentTime;
	
	String appType = "", appdir = "";
	String MCPIP = state.getString("MCPIP");
	boolean isDebugEnabled = false;
	File propFile = new File(getServletConfig().getServletContext().getRealPath("Config/FSA.properties"));
	FileInputStream configStream = new FileInputStream(propFile);
	Properties proFlexxgate = new Properties();
	proFlexxgate.load(configStream);
	String CXI_hook = proFlexxgate.getProperty("CXI");
	String dbug = proFlexxgate.getProperty("debug");
	String loggerName = proFlexxgate.getProperty("LoggerName"); 
	String logFileSize = proFlexxgate.getProperty("LogFileSize"); 
	String logDir = proFlexxgate.getProperty("LogDir");
	String logLevel = proFlexxgate.getProperty("LogLevel");
	String filepath="";
	String NDM_NDMUrl = proFlexxgate.getProperty("NDM_URL");
	String NDM_DirURL = proFlexxgate.getProperty("Dir_URL");		
	String NDM_ApplicationPromptScriptDir = proFlexxgate.getProperty("NDM_ApplicationPromptScriptDir");
	String NDM_BaselinePromptDir = proFlexxgate.getProperty("NDM_BaselinePromptDir");
	String NDM_BrowserIp = proFlexxgate.getProperty("NDM_BrowserIp");	
	String NDM_PromptDir = proFlexxgate.getProperty("NDM_PromptDir");
	String NDM_GrammarDir = proFlexxgate.getProperty("NDM_GrammarDir");
	String NDM_SPPromptDir = proFlexxgate.getProperty("NDM_PromptDir_SP");
	String NDM_SPGrammarDir = proFlexxgate.getProperty("NDM_GrammarDir_SP");
	
	//for webservice eis config call
		String eisPath = getServletConfig().getServletContext().getRealPath("");
		Controller.eisConfigLoader(eisPath);
		
	//Get the Logger File Path
	if(logDir.endsWith("/")){
		filepath = logDir+loggerName+".log";
	}else{
		filepath = logDir+"/"+loggerName+".log";
	}
	
	//Configure the logger with the properties which are getting from Property files and System properties
	LoggerConfigure.loggerConfiguration(filepath, logFileSize.trim(),logLevel,loggerName);
	Logger debugLogger = Logger.getLogger(loggerName);
	
	try{
		debugLogger.info(loggingCommonFormat + "Call Established");
		
		//Create the session object
	    if( callID  !=  null  &&  callID.trim().length()  != 0  ){
	    	
	    	if( SessionObject.INSTANCE.getSession(callID)  ==  null ){
	    		
	    		//Create the Session
				SessionObject.INSTANCE.createSession(callID);
				
				//Get the values which is passed from GA.
				appType = state.getString("appType");
				//Logging Start point of an appl if this appl is not called from Outbound Appl.
				if ((dbug.equalsIgnoreCase("true")) || (dbug.equalsIgnoreCase("dev")) || (dbug.equalsIgnoreCase("connid"))) { 
					debugLogger.debug(loggingCommonFormat + "******************************************");
			    	debugLogger.debug(loggingCommonFormat + "************START OF THE CALL*************");
				}
	    	}else{
	    		
	    		//Get the values which is set 
				appType = (String) SessionObject.INSTANCE.getSession(callID).get("appType");
				
				dbug = (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled");
	    	}
	    	
	    	debugLogger.info(loggingCommonFormat + "Session Initiated with callID: " + callID);
	    }
		
	  //Initialize the values in Session here which are used in the application
	    if( SessionObject.INSTANCE.getSession(callID)  !=  null ){
	    	
	    	if(dbug.equalsIgnoreCase("true") || dbug.equalsIgnoreCase("dev"))
	    		SessionObject.INSTANCE.getSession(callID).put("isDebugEnabled", "true");
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("language", "en-US");
	    	
	    	// set the appsession attributes
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("ivrReason", "");
	    	//Set NDM values from property
	    	 SessionObject.INSTANCE.getSession(callID).put("NDM_NDMUrl",NDM_NDMUrl);
				SessionObject.INSTANCE.getSession(callID).put("NDM_DirURL",NDM_DirURL);
				SessionObject.INSTANCE.getSession(callID).put("NDM_ApplicationPromptScriptDir",NDM_ApplicationPromptScriptDir);
				SessionObject.INSTANCE.getSession(callID).put("NDM_BaselinePromptDir",NDM_BaselinePromptDir);
				SessionObject.INSTANCE.getSession(callID).put("NDM_BrowserIp",NDM_BrowserIp);
				SessionObject.INSTANCE.getSession(callID).put("NDM_PromptDir",NDM_PromptDir);
				SessionObject.INSTANCE.getSession(callID).put("NDM_GrammarDir",NDM_GrammarDir);
				SessionObject.INSTANCE.getSession(callID).put("NDM_SPPromptDir",NDM_SPPromptDir);
				SessionObject.INSTANCE.getSession(callID).put("NDM_SPGrammarDir",NDM_SPGrammarDir);
				
	    	
	    	//set the employee benefits session default values
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("memberSsn", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("callType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("policyNumber", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("state", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("transferReason", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("detailType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("commentsLong", "Unknown");
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("groupId", "");
	    	SessionObject.INSTANCE.getSession(callID).put("memberDob", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("dob", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("faxNumber", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("dmRootStatus", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("addType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("appType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("prodType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("appSeg", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("adminGroupId", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("pinNumber", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("planId", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("mHour", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("mMinute", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("mTimeZone", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("msgApptype", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("promptName", "medicare_msg");
	    	SessionObject.INSTANCE.getSession(callID).put("employeeId", "Unknown employee ID");
	    	SessionObject.INSTANCE.getSession(callID).put("PhoneNumber", ANI);
	    	SessionObject.INSTANCE.getSession(callID).put("DNIS", DNIS);
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("ANI", ANI);
	    	SessionObject.INSTANCE.getSession(callID).put("DID", DNIS);
	    	SessionObject.INSTANCE.getSession(callID).put("pin", "Unknown");
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("hours", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("caseManager", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("SSN", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("DOB", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("callReason", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("windowsType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("confirmCM", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("callerType", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("employeeName", "Unknown");
	    	SessionObject.INSTANCE.getSession(callID).put("Unknown", "0");
	    	SessionObject.INSTANCE.getSession(callID).put("ARRIVAL", "1");
	    	SessionObject.INSTANCE.getSession(callID).put("DEPARTURE", "2");
	    	SessionObject.INSTANCE.getSession(callID).put("DETAILS", "3");
	    	
	    	SessionObject.INSTANCE.getSession(callID).put("loginAttempts", "0");
	    	SessionObject.INSTANCE.getSession(callID).put("transferCall", "false");
	    	SessionObject.INSTANCE.getSession(callID).put("fsaError", "false");
	    	SessionObject.INSTANCE.getSession(callID).put("repeatFlag", "false");
	    	SessionObject.INSTANCE.getSession(callID).put("startOverFlag", "false");
	    	SessionObject.INSTANCE.getSession(callID).put("transferNum", "");
	    	SessionObject.INSTANCE.getSession(callID).put("FailureReason", "");
	    	
	    	Calendar startCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
			SessionObject.INSTANCE.getSession(callID).put("Glbl_start_date", currentDate);
			SessionObject.INSTANCE.getSession(callID).put("Glbl_start_time", currentTime);
			
			SessionObject.INSTANCE.getSession(callID).put("CXIReport",CXI_hook);
			String CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
			isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
			/* Enable the debug and print the values in log file*/
			if (isDebugEnabled){ 
	    		debugLogger.debug(loggingCommonFormat + " ");
	    		debugLogger.debug(loggingCommonFormat + "******************************************");
	    		debugLogger.debug(loggingCommonFormat + "In A1000_StartCall_Initialization");
	    		debugLogger.debug(loggingCommonFormat +"Current Date:"+currentDate);
	    		debugLogger.debug(loggingCommonFormat +"Call Start  Time:"+currentTime);
	    		debugLogger.debug(loggingCommonFormat +"APPTYPE:"+appType); 
	    		debugLogger.debug(loggingCommonFormat + "MCPIP : " + MCPIP);
	    		
	    	}
			
			/*Create the object reporting and classes */
			 	ReportCall reportCallObj=new ReportCall();
	     		SessionObject.INSTANCE.getSession(callID).put("ReportCallObj",reportCallObj);
	     		PP_And_Dm_States dmReportObj=new  PP_And_Dm_States();
	     		SessionObject.INSTANCE.getSession(callID).put("dmReportObj",dmReportObj);
	     	    CallflowEndReport callflowEndReportObj=new CallflowEndReport();
	     		SessionObject.INSTANCE.getSession(callID).put("callflowEndReportObj",callflowEndReportObj);
	     		ReportCall reportCall =(ReportCall)SessionObject.INSTANCE.getSession(callID).get("ReportCallObj");
	     	/* initialization of variable in reporting Object*/
	     		reportCall.setStartTime(startCal);
	     		reportCall.setAppServer(MCPIP);// set in properties in 
	 		 	reportCall.setApplicationID(appType);
					
				/* CXI Reportcall begin*/
				if(CXIhook.equals("Y")){
				GenerateReport CXIreport  = new GenerateReport();
				JSONObject ivrTransacation = new JSONObject();
				ivrTransacation.put("ANI", ANI);
				ivrTransacation.put("DNIS", DNIS);
				ivrTransacation.put("ENTRY_TIME",entryTime);   
				ivrTransacation.put("ApplicationID", "FSA");
				ivrTransacation.put("APP_VERSION", "1.0");
				ivrTransacation.put("LANGUAGE", state.getString("APP_LANGUAGE"));  
				ivrTransacation.put("IvrServer", "IVR_SERVER_MACHINE");
				ivrTransacation.put("AppServer", "gbtgenvar1p.nro.glic.com"); 		
				ivrTransacation.put("CallReason", "Unknown");
					ivrTransacation.put("IvrSessionID", sessionID);  
				CXIreport.beginTransaction(callID, "ENTRY_USER_DATA", ivrTransacation);	
				}
				/*CXI Report call end*/
	    	
				// check the app type and set the target_Callflow
	    	if("EB".equalsIgnoreCase(appType)){
	    		SessionObject.INSTANCE.getSession(callID).put("appType", "EB");
	    		SessionObject.INSTANCE.getSession(callID).put("target_callflow", "S1000_Welcome_PP");
	    		SessionObject.INSTANCE.getSession(callID).put("target_menu", "S1000_Welcome_PP");	    		
	    	}
	    	else if("PREMIER".equalsIgnoreCase(appType)){
	    		SessionObject.INSTANCE.getSession(callID).put("appType", "PREMIER");
	    		SessionObject.INSTANCE.getSession(callID).put("target_callflow", "GP1000_Welcome_PP");
	    		SessionObject.INSTANCE.getSession(callID).put("target_menu", "GP1000_Welcome_PP");		
	    	}
			else if("Meeting".equalsIgnoreCase(appType)){
	    		SessionObject.INSTANCE.getSession(callID).put("appType", "Meeting");
	    		SessionObject.INSTANCE.getSession(callID).put("target_callflow", "FSA_getAttData");
	    		SessionObject.INSTANCE.getSession(callID).put("target_menu", "FSA_getAttData");		
	    	}
			else{
				SessionObject.INSTANCE.getSession(callID).put("appType", "FSA");
	    		SessionObject.INSTANCE.getSession(callID).put("target_callflow", "A0000_FSA_Welcome_PP");
	    		SessionObject.INSTANCE.getSession(callID).put("target_menu", "A0000_FSA_Welcome_PP");
			}
	    }
	 
	}catch(Exception e){
		debugLogger.error(loggingCommonFormat + "Encountered exception A1000_StartCallInitialization: " + e.toString() ); 			
	}
	
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
