package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.scansoft.guardian.fsa.service.ServiceManager;
import com.scansoft.guardian.fsa.bean.*;
import com.google.gson.Gson;
import com.pointel.ivr.SessionObject;
import com.pointel.cxi.report.*;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class I3000_005fCallerTypeCheck_005fDS_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception
{
    
     //Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
       
    String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    boolean isDebugEnabled = false;
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    JSONObject result = new JSONObject();
    EligibilityLookup info = null;
    String CXIhook = "";
	   
    DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");		
   	Calendar now = Calendar.getInstance();
   	String currentDate = dateFormat.format(now.getTime());
    try{
    	 String callType = "";
    	 Policy policy = null;
    	 String memberSsn = "";
         if( SessionObject.INSTANCE.getSession(callID)  !=  null )
         {
    	  isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled") );
    	  callType = (String) SessionObject.INSTANCE.getSession(callID).get("callType");
          policy = (Policy) SessionObject.INSTANCE.getSession(callID).get("policy");
          memberSsn = (String) SessionObject.INSTANCE.getSession(callID).get("memberSsn");
          CXIhook=(String) SessionObject.INSTANCE.getSession(callID).get("CXIReport");
         }
       
	     if (isDebugEnabled)
	     {
		  debugLogger.debug(loggingCommonFormat + " ");
    	  debugLogger.debug(loggingCommonFormat + "******************************************");
    	  debugLogger.debug(loggingCommonFormat + "In I3000_CallerTypeCheck_DS");
	     }
	     try
	     {
	         
	           if(isDebugEnabled)
	           {
	       	     debugLogger.debug(loggingCommonFormat + "Calling task execute with following:");
	    	     debugLogger.debug(loggingCommonFormat + "SSN = " + memberSsn);
	    	     debugLogger.debug(loggingCommonFormat + "GID = " + policy.getGroupId());
	    	     debugLogger.debug(loggingCommonFormat + "DOB = " + policy.getDateOfBirth());
	           }
	           
	           // Web service Integration Start
 		       JSONObject request = new JSONObject();
	           request.put("taskName", "EligibilityLookupTask");
	           request.put("ssn", memberSsn);
	           request.put("groupId", policy.getGroupId());
	           request.put("dob", policy.getDateOfBirth());
	 		   if(callType != null && callType.equalsIgnoreCase("medical"))
	 		   {
		         request.put("type", "Medical");	 					
	 		   }else
	 		   {
		         request.put("type", "Dental");
	 		   }
	 		  if (isDebugEnabled)
	 	         {
	 	       		debugLogger.debug(loggingCommonFormat +"Send Request as Input: " +request.toString());
	 	         }
	 	         ServiceManager sm = new ServiceManager();
	 	         JSONObject jsonResponse = new JSONObject();
	 	         jsonResponse = sm.execute(request);
	 	         if (isDebugEnabled)
	 	         {
	 	          debugLogger.debug(loggingCommonFormat +"Get Response from Service:" + jsonResponse.toString());
	 	         }
	 	   	     if(jsonResponse.has("response"))
	 	   	     {
	 	   		  JSONObject jsonObj = jsonResponse.getJSONObject("response");
	 	   		  JSONObject responseBean = jsonObj.getJSONObject("EligibilityLookup");
	 	   		  info = new Gson().fromJson(responseBean.toString(), EligibilityLookup.class);
	 	   	//For Report					
					 if(CXIhook.equals("Y")){
					    	GenerateReport CXIreport  = new GenerateReport();
							JSONObject ivrTransacation = new JSONObject();
							ivrTransacation.put("ENTRY_TIME",currentDate);							
							ivrTransacation.put("DB_LOOKUP","Success");
							CXIreport.addFlow(callID,"I3000_CallerTypeCheck_DS",ivrTransacation);
					    	}	
	 	         }else
	 	         {
	 	           debugLogger.debug(loggingCommonFormat +"Json Response is wrong");
	 	        //For Report					
					 if(CXIhook.equals("Y")){
					    	GenerateReport CXIreport  = new GenerateReport();
							JSONObject ivrTransacation = new JSONObject();
							ivrTransacation.put("ENTRY_TIME",currentDate);							
							ivrTransacation.put("DB_LOOKUP","Failure");
							ivrTransacation.put("FAILURE_REASON","dbGet");
							CXIreport.addFlow(callID,"I3000_CallerTypeCheck_DS",ivrTransacation);
					    	}
					 result.put("NextCallFlow","transfer");
	 	   	     }	
	 	   	     // Web Service Integration end
	      }
	 	  catch(Exception ex)
	 	  {
	 		 debugLogger.error(loggingCommonFormat + "Cant Execute EIS Eligibility Lookup Task", ex);
	 	       SessionObject.INSTANCE.getSession(callID).put("failureReason","dbGet");
	 	       result.put("NextCallFlow","transfer");
	 	       result.put("event_msg","Cant Execute EIS Eligibility Lookup Task");
	 	  }	 		
	      if(info != null)
	      {
	 	       SessionObject.INSTANCE.getSession(callID).put("failureReason","");
	           if(isDebugEnabled)
	           {
	           	  debugLogger.debug(loggingCommonFormat + "EIS Returned Success");
	           }
		       SessionObject.INSTANCE.getSession(callID).put("eligibilityLookup",info);
	           if(callType != null && callType.equalsIgnoreCase("medical"))
	           {
	                if(info.isTerminated())
	                {
	               	  debugLogger.debug(loggingCommonFormat + "Caller has term flag true");
	            	  debugLogger.debug(loggingCommonFormat + "Termination Date = " + info.getTerminationDate());
	                }else
	                {
	               	  debugLogger.debug(loggingCommonFormat + "Caller has term flag false");
	                }
			         SessionObject.INSTANCE.getSession(callID).put("target_menu","D1000_AskFax_DM"); 
			         result.put("NextCallFlow","false");
	           }
	           if(info.isTerminated())
	           {
	           	   debugLogger.debug(loggingCommonFormat + "Caller has term flag true");
		           SessionObject.INSTANCE.getSession(callID).put("transferReason","Terminated"); 
		           SessionObject.INSTANCE.getSession(callID).put("target_menu","D1000_AskFax_DM"); 
		           result.put("NextCallFlow","false");
	           }else
	           {
	           	   debugLogger.debug(loggingCommonFormat + "------------    eligibility test passed ");
	         	   SessionObject.INSTANCE.getSession(callID).put("target_menu","D1000_AskFax_DM"); 
	         	   result.put("NextCallFlow","false");		
	           }
	      }
	      if(isDebugEnabled)
	      {
	       	   debugLogger.debug(loggingCommonFormat + "EIS Returned NULL");
	      }
	      result.put("NextCallFlow","transfer");
	      result.put("event_msg","transfer");          
	  }catch(Exception ex) //Log Error Info 
       {
		  debugLogger.error(loggingCommonFormat + "should never reach here");
        result.put("NextCallFlow","transfer");
        result.put("event_msg","should never reach here");            
       }			
    return result;   
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n \r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
