package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class NDM_005fCheckType_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
    	 
	JSONObject result = new JSONObject();

	Logger logger = LogManager.getLogger("CUSTOM_LOGGER");
	String NDM_sessionID = state.getString("GVPSessionID").split(";")[0];
    String NDM_callID = state.getString("CallUUID").trim();	
    String NDM_logInfo = " {" + NDM_sessionID + "}, " + NDM_callID + ",";
	
	logger.debug(NDM_logInfo + "");
	logger.debug(NDM_logInfo + "******************************************");
	logger.debug(NDM_logInfo + "In NDM_CheckType");
	String NDM_dmType = state.getString("NDM_dmname");
	String NDM_collectionDefaultConfirmation = state.getString("NDM_collection_defaultconfirmation");
	String NDM_successPrompts1 = state.getString("NDM_successprompts1");
	String NDM_confirmationInitialPrompt = state.getString("NDM_confirmation_initialprompt");
	String NDM_maxNoInput = state.getString("NDM_maxnoinputs");
	String NDM_collectionNoInputPrompts1 = state.getString("NDM_collection_noinputprompts1");
	String NDM_collectionNoInputPrompts2 = state.getString("NDM_collection_noinputprompts2"); 

	//No Answer Apologies are depricated & replaced by no match in NDM
	String NDM_collectionNoMatchPrompt1 = state.getString("NDM_collection_nomatchprompt1");
	String NDM_collectionNoMatchPrompt2 = state.getString("NDM_collection_nomatchprompt2");		

	//Wrong Answer Apologies are depricated & replaced by No to confirm in NDM
	String NDM_collectionNotoConfirmPrompt1 = state.getString("NDM_collection_notoconfirmprompt1");
	String NDM_collectionNotoConfirmPrompt2 = state.getString("NDM_collection_notoconfirmprompt2");

	String NDM_module = state.getString("NDM_Main_Module");
	String NDM_langParam = state.getString("NDM_lang");
	String NDM_callPath = "";
	String NDM_collectionInitialPrompt = state.getString("NDM_collection_initialprompt");
	String NDM_collectionGrammar1 = state.getString("NDM_collection_grammar1");
	String NDM_collectionDTMFGrammar1 = state.getString("NDM_collection_dtmfgrammar1");
	String NDM_incompleteTimeout = state.getString("NDM_incompletetimeout");

	String NDM_confirmationGrammar1  = state.getString("NDM_confirmation_grammar1");
	String NDM_collectionHighconfidencelevel = state.getString("NDM_collection_highconfidencelevel");
	String NDM_propertyConfidenceLevel = state.getString("NDM_property_confidencelevel");
	String NDM_correctedCollectionConfidenceLevel = state.getString("NDM_corrected_collection_confidencelevel");
	String NDM_propertyConfirmationConfidenceLevel = state.getString("NDM_property_confirmation_confidencelevel");
	String NDM_maxturns = state.getString("NDM_maxturns");
	
	try{
		
		logger.debug(NDM_logInfo + "");
		logger.debug(NDM_logInfo + "******************************************"); 
		logger.debug(NDM_logInfo + "In NDM_ChkType");
		
		if (NDM_dmType != null && NDM_dmType.equals("naturalnumbers")){
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_NaturalNumbers");
	
			result.put("NDM_goto" , "5"); 
	
		} else if (NDM_dmType != null && NDM_dmType.equals("date")){
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_Date");
	
			result.put("NDM_goto" , "3");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("digits")) {
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_Digits");
			result.put("NDM_goto" , "4");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("yesno")){
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_YesNo");
	
			result.put("NDM_goto" , "6");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("zipcode")){
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_Zipcode");
	
			result.put("NDM_goto" , "7");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("currency")){
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In NDM_Currency");
	
			result.put("NDM_goto" , "2");
	
		} else {
			
			logger.debug(NDM_logInfo + "");
			logger.debug(NDM_logInfo + "******************************************");
			logger.debug(NDM_logInfo + "In CustomContext");
	
			result.put("NDM_goto" , "1");
		}
	} catch(Exception exc){
		
		logger.error(NDM_logInfo + "Encountered exception NDM_CheckType: " + exc.toString() );	
	}


    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
