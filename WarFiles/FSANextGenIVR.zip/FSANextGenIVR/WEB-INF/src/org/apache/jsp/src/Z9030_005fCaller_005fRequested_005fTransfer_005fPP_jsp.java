package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import org.apache.log4j.Logger;
import java.util.Date;
import java.util.Properties;
import java.io.File;
import java.io.FileInputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class Z9030_005fCaller_005fRequested_005fTransfer_005fPP_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {

    JSONObject result = new JSONObject();
    
  	//Get logger instance and common logging things(SessionID, Connection ID, Current timestamp)
    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
       
    String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    boolean isDebugEnabled = false;
    boolean	transferCall = false;
    JSONArray PromptList = new JSONArray();
    String appDir = "";
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";

    if( SessionObject.INSTANCE.getSession(callID)  !=  null ){
    	isDebugEnabled = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled") );    
    	transferCall = java.lang.Boolean.valueOf( (String) SessionObject.INSTANCE.getSession(callID).get("transferCall") );
    	appDir = (String)SessionObject.INSTANCE.getSession(callID).get("APPDIR"); 
    	
    	if (isDebugEnabled){
    		debugLogger.debug(loggingCommonFormat + " ");
    		debugLogger.debug(loggingCommonFormat + "******************************************");
    		debugLogger.debug(loggingCommonFormat + "In Z9030_Caller_Requested_Transfer_PP");
  
   	 		try{
				// transfer route point
   	 			String propFilePath =  appDir + "/FSA.properties";
	 	    	File propFile = new File(propFilePath);	
	 	    	FileInputStream configStream = new FileInputStream(propFile);
	 			Properties proFlexxgate = new Properties();
	 			proFlexxgate.load(configStream);
	 			
	 			// Prompts and Type as input
   	 			if(transferCall){
   	 				
   	 				PromptList.put("audio,9030_pp1.ulaw");
   	 				SessionObject.INSTANCE.getSession(callID).put("RoutePoint",proFlexxgate.getProperty("FSA_Transfer_Other_routepoint")); 
   	 				SessionObject.INSTANCE.getSession(callID).put("Transfer","true"); 
   	 			}else{
   	 				
   	 				PromptList.put("audio,9030_pp2.ulaw");
   	 				SessionObject.INSTANCE.getSession(callID).put("Transfer","false"); 
   	 			}
   	 			
   	 			result.put("PromptList",PromptList);
   	 			result.put("StateName","Z9030_Caller_Requested_Transfer");
   	 			SessionObject.INSTANCE.getSession(callID).put("target_menu","Z9999_TerminateCall");
   	 			result.put("NextCallFlow","false");
   	 			
    		} catch (Exception exc) {	//Log error info
    			debugLogger.error(loggingCommonFormat + "Encountered exception in Z9030_Caller_Requested_Transfer_PP: " + exc.toString() ); 
    		}
		}
	}
    
    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write('\r');
      out.write('\n');
      out.write(" \r\n\r\n\r\n\r\n \r\n \r\n \r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
