package org.apache.jsp.src;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.pointel.ivr.SessionObject;
import org.apache.log4j.Logger;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import org.json.JSONObject;
import com.genesyslab.studio.backendlogic.GVPHttpRequestProcessor;
import java.util.Map;

public final class FSA_005fNDM_005fCheckType_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {


// Implement this method to execute some server-side logic.
public JSONObject performLogic(JSONObject state, Map<String, String> additionalParams) throws Exception {
    	 
	JSONObject result = new JSONObject();

    Logger debugLogger = Logger.getLogger("IvrAppLogger");  
	
  	String sessionID = state.getString("GVPSessionID").split(";")[0];
    String callID = state.getString("CallUUID").trim();
    Date timeStamp = new Date();
    String loggingCommonFormat = "{" + sessionID + "}," + callID + "," + timeStamp + ",";
    boolean isDebugEnabled = false ;
	
    if( SessionObject.INSTANCE.getSession(callID)  !=  null ){
		isDebugEnabled = java.lang.Boolean.valueOf((String)SessionObject.INSTANCE.getSession(callID).get("isDebugEnabled"));
    }
    
    if(isDebugEnabled){
		debugLogger.debug(loggingCommonFormat + "");
		debugLogger.debug(loggingCommonFormat + "******************************************");
		debugLogger.debug(loggingCommonFormat + "In NDM_CheckType");
    }
    
	String NDM_dmType = state.getString("ndm_type");
	
	String NDM_collectionNoInputPrompts1 = state.getString("collection_noinputprompts1");
	String NDM_collectionNoInputPrompts2 = state.getString("collection_noinputprompts2"); 

	//No Answer Apologies are depricated & replaced by no match in NDM
	String NDM_collectionNoMatchPrompt1 = state.getString("collection_nomatchprompt1");
	String NDM_collectionNoMatchPrompt2 = state.getString("collection_nomatchprompt2");		

	String NDM_module = state.getString("NDM_Main_Module");
	String NDM_langParam = state.getString("lang");
	String NDM_callPath = "";
	String NDM_collectionInitialPrompt = state.getString("collection_initialprompt");
	String NDM_collectionGrammar1 = state.getString("collection_grammar1");
	String NDM_collectionDTMFGrammar1 = state.getString("collection_dtmfgrammar1");
	String NDM_confirmationGrammar1  = state.getString("confirmation_grammar1");
	String NDM_collection_commandgrammar1 = state.getString("collection_commandgrammar1");
	String NDM_collection_dtmfcommandgrammar1 = state.getString("collection_dtmfcommandgrammar1");
	
	if(isDebugEnabled){
		debugLogger.debug(loggingCommonFormat + "NDM_collection_initialprompt: " + NDM_collectionInitialPrompt);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionNoInputPrompts1: " + NDM_collectionNoInputPrompts1);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionNoInputPrompts2: " + NDM_collectionNoInputPrompts2);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionNoMatchPrompt1: " + NDM_collectionNoMatchPrompt1);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionNoMatchPrompt2: " + NDM_collectionNoMatchPrompt2);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionGrammar1: " + NDM_collectionGrammar1);
		debugLogger.debug(loggingCommonFormat + "NDM_collectionDTMFGrammar1: " + NDM_collectionDTMFGrammar1);
		debugLogger.debug(loggingCommonFormat + "NDM_confirmationGrammar1: " + NDM_confirmationGrammar1);
		debugLogger.debug(loggingCommonFormat + "NDM_collection_commandgrammar1: " + NDM_collection_commandgrammar1);
		debugLogger.debug(loggingCommonFormat + "NDM_collection_dtmfcommandgrammar1: " + NDM_collection_dtmfcommandgrammar1);
		debugLogger.debug(loggingCommonFormat + "NDM_module: " + NDM_module);
		debugLogger.debug(loggingCommonFormat + "NDM_langParam: " + NDM_langParam);
	}
	
	
	try{
		
		if (NDM_dmType != null && NDM_dmType.equals("naturalnumbers")){
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_NaturalNumbers");
			}
	
			result.put("NDM_goto" , "5"); 
	
		} else if (NDM_dmType != null && NDM_dmType.equals("date")){
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_Date");
			}
	
			result.put("NDM_goto" , "3");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("digits")) {
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_Digits");
			}
			
			result.put("NDM_goto" , "4");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("yesno")){
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_YesNo");
			}
	
			result.put("NDM_goto" , "6");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("zipcode")){
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_Zipcode");
			}
			
			result.put("NDM_goto" , "7");
	
		} else if (NDM_dmType != null && NDM_dmType.equals("currency")){
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In NDM_Currency");
			}
			
			result.put("NDM_goto" , "2");
	
		} else {
			
			if(isDebugEnabled){
				debugLogger.debug(loggingCommonFormat + "");
				debugLogger.debug(loggingCommonFormat + "******************************************");
				debugLogger.debug(loggingCommonFormat + "In CustomContext");
			}
	
			result.put("NDM_goto" , "1");
		}
	} catch(Exception exc){
		
		debugLogger.error(loggingCommonFormat + "Encountered exception NDM_CheckType: " + exc.toString() );	
	}


    return result;
    
};

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/src/../include/backend.jspf");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("application/json;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n\r\n");
      out.write('\r');
      out.write('\n');
      out.write("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
      out.write("\r\n\r\n\r\n\r\n\r\n");

response.setHeader("Cache-Control", "no-cache");

String output = null;

try {
    // process the post data
    GVPHttpRequestProcessor processor = new GVPHttpRequestProcessor(request);
    processor.parseRequest();
    
    // "state" encapsulates the state variable submitted by the VXML page
    JSONObject state = processor.getState();
    
    // additional parameters that were passed in the namelist
    Map<String, String> additionalParams = processor.getAdditionalParams();
    
    // perform the logic
    JSONObject result = performLogic(state, additionalParams);
    
	output = result.toString();
    
    out.print(output);
    
} catch (Exception e) {
    
    e.printStackTrace();
    String msg = e.getMessage();
    if (null != msg){
    	msg = msg.replace('"', '\'');
    }
	out.print("{\"errorMsg\": \"" + msg + "\"}");
	
}

      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
